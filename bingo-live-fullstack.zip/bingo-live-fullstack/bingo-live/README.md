# 🎱 BingoLive — Dream11-Style Live Bingo Platform

A full-stack, production-architected live multiplayer Bingo/Housie contest platform.
Backend: **Java 17 + Spring Boot 3**. Frontend: **Angular 17 (standalone components)**.
Real-time gameplay over **WebSocket (STOMP/SockJS)**, with **voice announcements** for every called number.

---

## ✅ What changed based on your feedback

| Your feedback | Fix |
|---|---|
| "Too fast, numbers called too quickly" | Call interval is now **20 seconds** (configurable via `app.game.number-call-interval-seconds`) |
| "Add voice" | Added **Web Speech API** voice service — announces every number with classic Housie nicknames ("Legs Eleven", "Two Fat Ladies", etc.), plus countdown and prize-win announcements |
| "Java + Angular, follow system design" | Rebuilt as a layered Spring Boot backend (Controller → Service → Repository) + Angular standalone-component frontend, communicating over REST + WebSocket |

---

## 📁 Project Structure

```
bingo-live/
├── backend/                          Spring Boot 3 (Java 17)
│   ├── pom.xml
│   └── src/main/java/com/bingolive/
│       ├── BingoLiveApplication.java
│       ├── config/                   Security, WebSocket, JPA config
│       ├── controller/                REST endpoints (Auth, Contest, Wallet)
│       ├── dto/request, dto/response  Request/response payloads
│       ├── entity/                    JPA entities (User, Contest, GameParticipant…)
│       ├── enums/                     GameStatus, PrizeType, TransactionType
│       ├── exception/                 Global exception handling
│       ├── repository/                Spring Data JPA repositories
│       ├── security/                  JWT filter + service
│       └── service/impl/              Business logic incl. GameEngineService
│
└── frontend/                         Angular 17 (standalone components)
    └── src/app/
        ├── core/
        │   ├── guards/                 authGuard, guestGuard
        │   ├── interceptors/           JWT auth interceptor
        │   └── services/               auth, contest, wallet, websocket, voice
        ├── shared/models/               TypeScript interfaces (mirrors backend DTOs)
        └── features/
            ├── auth/login, auth/register
            ├── lobby/                   Contest listing
            ├── game/                    Live gameplay screen
            └── wallet/                  Wallet + transaction history
```

---

## 🏗 System Design

### High-level architecture

```
┌─────────────┐        REST (JWT)         ┌──────────────────┐
│   Angular   │ ─────────────────────────▶│  Spring Boot API  │
│  Frontend   │ ◀───────────────────────── │  (Controllers)    │
└─────────────┘                            └────────┬─────────┘
       │                                             │
       │     WebSocket (STOMP/SockJS)                ▼
       │ ◀──────────────────────────────  ┌──────────────────┐
       └────────────────────────────────▶ │  GameEngineService │
                                           │  (in-memory state +│
                                           │   scheduled tasks) │
                                           └────────┬───────────┘
                                                     │
                                          ┌──────────▼──────────┐
                                          │   JPA / H2 (dev)     │
                                          │   → PostgreSQL (prod)│
                                          └───────────────────────┘
```

### Why this design

**REST for state-changing actions** (register, login, join contest, add funds) — these need
guaranteed delivery, validation, and a clear request/response cycle.

**WebSocket (STOMP over SockJS) for live game events** — number calls, prize wins, and
countdowns are broadcast to all subscribers of `/topic/game/{contestId}` the instant they
happen, with automatic SockJS fallback for older browsers/networks.

**Scheduled task per active contest** — `GameEngineService` uses a
`ScheduledExecutorService` to call one number every `N` seconds per contest. Each contest's
state (remaining numbers, called-numbers set) lives in a `ConcurrentHashMap`, isolated per
`contestId`, so contests run independently and in parallel.

**Stateless JWT auth** — no server-side session store needed; horizontally scalable.
The same JWT is passed as a STOMP `CONNECT` header so the WebSocket handshake is authenticated.

### Database schema (core tables)

```
users               id, full_name, email, phone, password_hash, wallet_balance, kyc_verified
contests            id, name, prize_pool, entry_fee, max_players, current_players, status, badge
game_participants   id, user_id, contest_id, card_data, total_earnings   (UNIQUE user_id+contest_id)
called_numbers      id, contest_id, number, call_sequence, called_at
prize_wins          id, contest_id, user_id, prize_type, amount, won_at  (UNIQUE contest_id+prize_type)
wallet_transactions id, user_id, type, amount, balance_after, description, reference_id
```

`prize_wins` enforces **one winner per prize type per contest** — exactly like Dream11/My11Circle,
the first participant whose card satisfies a prize condition wins it; everyone else is locked out
of that specific prize for that game.

### Prize Rules (matches your spec)

| Prize | Condition | Payout |
|---|---|---|
| Early Five | First 5 numbers marked on your card | ₹15 |
| 1st / 2nd / 3rd Line | Any full row of the 3×9 card complete | ₹10 each |
| Top Half | Rows 1+2 both complete | ₹25 |
| Full House | All 15 numbers on the card marked | ₹100 |

All rule amounts/conditions are defined in one place — `PrizeType.java` (backend) and
`PRIZE_DEFINITIONS` (frontend `models/index.ts`) — change them there to reconfigure payouts
per your actual business rules. The contest's `prizePool` and `entryFee` are independent
per-contest values seeded in `ContestService`.

### Concurrency & fairness

- Each contest's number queue is shuffled once at game start (`Collections.shuffle`), so all
  90 numbers are called in random order with no repeats — exactly like physical Housie.
- Prize checks run **after every single number call**, checked against **all participants**,
  so the first person to complete a condition wins it — ties are broken by iteration order,
  but in practice a 20-second gap between calls means real card-completion timing decides it.
- `@Transactional` wraps wallet debits/credits so a participant can never be charged twice or
  paid twice for the same prize.

---

## 🚀 Running locally

### Backend

```bash
cd backend
./mvnw spring-boot:run
# or if you don't have the wrapper:
mvn spring-boot:run
```

Runs on `http://localhost:8080`, context path `/api`.
H2 console available at `http://localhost:8080/api/h2-console` (JDBC URL: `jdbc:h2:mem:bingolive`).

5 demo contests are auto-seeded on first run (see `ContestService.run()`).

### Frontend

```bash
cd frontend
npm install
npm start
```

Runs on `http://localhost:4200`, proxies `/api/**` to the backend per `proxy.conf.json`.

### Try it out

1. Open `http://localhost:4200` → redirected to `/login`
2. Click "Create one" → register (get ₹500 welcome bonus automatically)
3. Lobby shows 5 live contests with different entry fees/prize pools
4. Join any contest you can afford → entry fee deducted, redirected to game screen
5. When 10 players have joined (or you can lower `maxPlayers` for testing), a 10-second
   countdown begins, then numbers call every **20 seconds** with **voice announcement**
6. Tap called numbers on your card (or leave Auto-Mark on) — prizes are detected and
   credited to your wallet automatically with a toast + win sound

---

## ⚙️ Key configuration

`backend/src/main/resources/application.properties`:

```properties
app.game.number-call-interval-seconds=20   # ← the speed fix you asked for
app.game.waiting-room-seconds=30
app.jwt.secret=...                          # change in production!
app.jwt.expiration-ms=86400000              # 24 hours
```

To go faster/slower for testing, just change `number-call-interval-seconds` and restart.

---

## 🔊 Voice feature details

`frontend/src/app/core/services/voice.service.ts` uses the browser's native
**Web Speech API** (`SpeechSynthesisUtterance`) — no external API key or cost.

- Every called number is announced, using classic Housie nicknames where they exist
  (1 = "Kelly's Eye", 11 = "Legs Eleven", 88 = "Two Fat Ladies", etc.) and falling back to
  "Number N" otherwise.
- Countdown announces the last 5 seconds aloud.
- Prize wins are announced by name ("Congratulations Rahul! Full House claimed!").
- A mute/unmute toggle (🔊/🔇) sits in the game header; state is local to the session.
- A short Web-Audio-API beep also plays on every call as an additional non-verbal cue, and a
  4-note win arpeggio plays when you personally win a prize.

---

## 🔐 Security notes for production

- Swap the H2 in-memory DB for PostgreSQL (dependency already commented in `pom.xml`) —
  H2 data is lost on every restart.
- Move `app.jwt.secret` to an environment variable / secrets manager — never commit a real
  secret to source control.
- Add rate limiting on `/auth/login` and `/contests/{id}/join` to prevent brute-force/abuse.
- Add real KYC + payment gateway integration before handling real money — this build uses an
  in-app "Add Funds" simulator with no real payment processor, and is **not** wired to any
  bank/UPI rail. Real-money gaming also has state-specific legal requirements in India
  (skill-game classification, GST on prize pool, age/state restrictions) that must be handled
  before going live with actual currency.

---

## 🧪 Tests

`backend/src/test/java/com/bingolive/BingoCardServiceTest.java` covers card generation,
serialization round-tripping, and all prize-condition logic. Run with:

```bash
cd backend
mvn test
```

---

## 🛣 Suggested next steps

- Redis-backed game state instead of `ConcurrentHashMap` so the engine survives backend
  restarts and can scale across multiple instances (currently single-instance only).
- Admin panel to create/edit contests instead of hardcoded seed data.
- Leaderboard / contest history page per user.
- Push notifications when a joined contest is about to start.
- Dockerfile + docker-compose for one-command local spin-up of backend + Postgres + frontend.
