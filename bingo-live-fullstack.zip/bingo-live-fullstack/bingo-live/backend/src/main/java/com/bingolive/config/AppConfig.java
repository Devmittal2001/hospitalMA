package com.bingolive.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.scheduling.annotation.EnableAsync;

@Configuration
@EnableJpaAuditing
@EnableAsync
public class AppConfig {
    // JPA auditing enables @CreatedDate and @LastModifiedDate
}
