package com.bingolive.controller;

import com.bingolive.dto.response.ContestResponse;
import com.bingolive.entity.GameParticipant;
import com.bingolive.repository.UserRepository;
import com.bingolive.service.impl.ContestService;
import com.bingolive.service.impl.GameEngineService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/contests")
@RequiredArgsConstructor
public class ContestController {

    private final ContestService contestService;
    private final GameEngineService gameEngineService;
    private final UserRepository userRepository;

    @GetMapping
    public ResponseEntity<List<ContestResponse>> getActiveContests() {
        return ResponseEntity.ok(contestService.getAllActiveContests());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ContestResponse> getContest(@PathVariable Long id) {
        return ResponseEntity.ok(contestService.getById(id));
    }

    @PostMapping("/{id}/join")
    public ResponseEntity<Map<String, Object>> joinContest(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {

        Long userId = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow().getId();

        GameParticipant participant = gameEngineService.joinContest(userId, id);

        return ResponseEntity.ok(Map.of(
                "message", "Successfully joined contest",
                "cardData", participant.getCardData(),
                "participantId", participant.getId()
        ));
    }

    @GetMapping("/{id}/called-numbers")
    public ResponseEntity<List<Integer>> getCalledNumbers(@PathVariable Long id) {
        return ResponseEntity.ok(gameEngineService.getCalledNumbers(id));
    }
}
