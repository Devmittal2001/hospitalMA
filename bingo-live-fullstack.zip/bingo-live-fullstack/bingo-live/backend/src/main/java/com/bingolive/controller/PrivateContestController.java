package com.bingolive.controller;

import com.bingolive.dto.request.CreatePrivateContestRequest;
import com.bingolive.dto.request.JoinPrivateContestRequest;
import com.bingolive.dto.response.PrivateContestResponse;
import com.bingolive.repository.UserRepository;
import com.bingolive.service.impl.PrivateContestService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/private-contests")
@RequiredArgsConstructor
public class PrivateContestController {

    private final PrivateContestService service;
    private final UserRepository userRepo;

    /**
     * POST /private-contests
     * Create a new private contest. Creator is auto-joined.
     */
    @PostMapping
    public ResponseEntity<PrivateContestResponse> create(
            @Valid @RequestBody CreatePrivateContestRequest req,
            @AuthenticationPrincipal UserDetails userDetails) {

        Long userId = getUserId(userDetails);
        return ResponseEntity.ok(service.createContest(userId, req));
    }

    /**
     * POST /private-contests/join
     * Join via invite code + passcode. Rate-limited and brute-force protected.
     */
    @PostMapping("/join")
    public ResponseEntity<PrivateContestResponse> join(
            @Valid @RequestBody JoinPrivateContestRequest req,
            @AuthenticationPrincipal UserDetails userDetails,
            HttpServletRequest httpRequest) {

        Long userId = getUserId(userDetails);
        return ResponseEntity.ok(service.joinContest(userId, req, httpRequest));
    }

    /**
     * GET /private-contests/{id}
     * Fetch current contest state by numeric ID — used by the game page on
     * load/refresh. Includes the requesting user's cardData if they've joined.
     *
     * Route constrained to digits only ({id:[0-9]+}) so it never collides with
     * the /lookup/{inviteCode} path below, which uses alphanumeric codes.
     */
    @GetMapping("/{id:[0-9]+}")
    public ResponseEntity<PrivateContestResponse> getById(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {

        Long userId = getUserId(userDetails);
        return ResponseEntity.ok(service.getById(id, userId));
    }

    /**
     * GET /private-contests/lookup/{inviteCode}
     * Preview contest info before joining (no passcode needed to preview).
     */
    @GetMapping("/lookup/{inviteCode}")
    public ResponseEntity<PrivateContestResponse> lookup(
            @PathVariable String inviteCode,
            @AuthenticationPrincipal UserDetails userDetails) {

        Long userId = getUserId(userDetails);
        return ResponseEntity.ok(service.getByInviteCode(inviteCode, userId));
    }

    /**
     * GET /private-contests/my
     * Get all contests the user created or joined.
     */
    @GetMapping("/my")
    public ResponseEntity<List<PrivateContestResponse>> myContests(
            @AuthenticationPrincipal UserDetails userDetails) {

        Long userId = getUserId(userDetails);
        return ResponseEntity.ok(service.getMyContests(userId));
    }

    /**
     * POST /private-contests/{id}/start
     * Creator manually starts the game early (without waiting for full lobby).
     */
    @PostMapping("/{id}/start")
    public ResponseEntity<Map<String, String>> startNow(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {

        Long userId = getUserId(userDetails);
        service.startNow(id, userId);
        return ResponseEntity.ok(Map.of("message", "Game starting!"));
    }

    private Long getUserId(UserDetails userDetails) {
        return userRepo.findByEmail(userDetails.getUsername()).orElseThrow().getId();
    }
}
