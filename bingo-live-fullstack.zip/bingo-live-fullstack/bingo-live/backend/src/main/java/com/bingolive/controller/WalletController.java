package com.bingolive.controller;

import com.bingolive.dto.request.AddFundsRequest;
import com.bingolive.entity.WalletTransaction;
import com.bingolive.repository.UserRepository;
import com.bingolive.service.impl.WalletService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/wallet")
@RequiredArgsConstructor
public class WalletController {

    private final WalletService walletService;
    private final UserRepository userRepository;

    @GetMapping("/balance")
    public ResponseEntity<Map<String, BigDecimal>> getBalance(
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = getUserId(userDetails);
        return ResponseEntity.ok(Map.of("balance", walletService.getBalance(userId)));
    }

    @PostMapping("/add-funds")
    public ResponseEntity<Map<String, Object>> addFunds(
            @Valid @RequestBody AddFundsRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = getUserId(userDetails);
        BigDecimal newBalance = walletService.addFunds(userId, request.getAmount());
        return ResponseEntity.ok(Map.of("balance", newBalance, "message", "Funds added successfully"));
    }

    @GetMapping("/history")
    public ResponseEntity<List<WalletTransaction>> getHistory(
            @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = getUserId(userDetails);
        return ResponseEntity.ok(walletService.getHistory(userId));
    }

    private Long getUserId(UserDetails userDetails) {
        return userRepository.findByEmail(userDetails.getUsername()).orElseThrow().getId();
    }
}
