package com.bingolive.dto.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.math.BigDecimal;

@Data
public class AddFundsRequest {
    @NotNull
    @DecimalMin(value = "10.00", message = "Minimum deposit is ₹10")
    private BigDecimal amount;
}
