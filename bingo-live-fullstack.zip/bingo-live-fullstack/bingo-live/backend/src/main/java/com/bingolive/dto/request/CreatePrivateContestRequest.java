package com.bingolive.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class CreatePrivateContestRequest {

    @NotBlank(message = "Contest name is required")
    @Size(min = 3, max = 60, message = "Name must be 3–60 characters")
    private String name;

    @Size(max = 300, message = "Description max 300 characters")
    private String description;

    @NotNull(message = "Entry fee is required")
    @DecimalMin(value = "10.00", message = "Minimum entry fee is ₹10")
    @DecimalMax(value = "10000.00", message = "Maximum entry fee is ₹10,000")
    private BigDecimal entryFee;

    @Min(value = 2,  message = "Minimum 2 players")
    @Max(value = 50, message = "Maximum 50 players")
    private int maxPlayers;

    @Min(value = 10,  message = "Minimum 10 seconds between calls")
    @Max(value = 60,  message = "Maximum 60 seconds between calls")
    private int callIntervalSeconds;

    @NotBlank(message = "Passcode is required")
    @Pattern(regexp = "^[0-9]{4,8}$", message = "Passcode must be 4–8 digits")
    private String passcode;

    private boolean publiclyListed;

    // Custom prize rules — creator defines each prize and its amount
    @NotNull
    @Size(min = 1, max = 6)
    private List<PrizeRuleDto> prizeRules;

    @Data
    public static class PrizeRuleDto {
        @NotBlank
        private String prizeType; // EARLY_FIVE, FIRST_LINE, SECOND_LINE, THIRD_LINE, TOP_HALF, FULL_HOUSE
        @Min(0) @Max(100000)
        private int amount;
    }
}
