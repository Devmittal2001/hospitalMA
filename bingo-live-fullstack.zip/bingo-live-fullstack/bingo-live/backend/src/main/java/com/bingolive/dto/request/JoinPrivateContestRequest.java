package com.bingolive.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class JoinPrivateContestRequest {

    // Either inviteCode from URL or typed manually
    @NotBlank(message = "Invite code is required")
    private String inviteCode;

    // The passcode the user enters
    @NotBlank(message = "Passcode is required")
    private String passcode;
}
