package com.bingolive.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class RegisterRequest {
    @NotBlank(message = "Full name is required")
    @Size(min = 2, max = 50)
    private String fullName;

    @NotBlank @Email(message = "Invalid email")
    private String email;

    @NotBlank
    @Pattern(regexp = "^[6-9]\\d{9}$", message = "Invalid Indian mobile number")
    private String phone;

    @NotBlank
    @Size(min = 6, max = 30, message = "Password must be 6-30 characters")
    private String password;
}
