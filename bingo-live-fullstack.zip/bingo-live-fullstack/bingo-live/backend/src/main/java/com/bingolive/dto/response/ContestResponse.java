package com.bingolive.dto.response;

import com.bingolive.enums.GameStatus;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ContestResponse {
    private Long id;
    private String name;
    private BigDecimal prizePool;
    private BigDecimal entryFee;
    private int maxPlayers;
    private int currentPlayers;
    private GameStatus status;
    private String badge;
    private String colorHex;
    private LocalDateTime createdAt;
    private LocalDateTime startedAt;
    private int spotsLeft;
    private double fillPercentage;
}
