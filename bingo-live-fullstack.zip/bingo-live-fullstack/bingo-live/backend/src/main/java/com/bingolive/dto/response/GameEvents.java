package com.bingolive.dto.response;

import com.bingolive.enums.GameStatus;
import com.bingolive.enums.PrizeType;
import lombok.*;
import java.util.List;

// ── Sent over WebSocket: /topic/game/{contestId} ────────────────────────────

@Data @Builder @NoArgsConstructor @AllArgsConstructor
class NumberCalledEvent {
    private String type = "NUMBER_CALLED";
    private int number;
    private int callSequence;
    private List<Integer> allCalledNumbers;
    private int nextCallInSeconds;
}

@Data @Builder @NoArgsConstructor @AllArgsConstructor
class PrizeWonEvent {
    private String type = "PRIZE_WON";
    private Long userId;
    private String winnerName;
    private PrizeType prizeType;
    private int amount;
    private int calledNumbersAtWin;
}

@Data @Builder @NoArgsConstructor @AllArgsConstructor
class GameStatusEvent {
    private String type = "GAME_STATUS";
    private GameStatus status;
    private int currentPlayers;
    private int maxPlayers;
    private String message;
}

@Data @Builder @NoArgsConstructor @AllArgsConstructor
class GameStartingEvent {
    private String type = "GAME_STARTING";
    private int countdownSeconds;
}
