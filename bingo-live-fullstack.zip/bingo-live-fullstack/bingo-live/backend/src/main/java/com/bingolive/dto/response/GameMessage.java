package com.bingolive.dto.response;

import com.bingolive.enums.GameStatus;
import com.bingolive.enums.PrizeType;
import lombok.*;
import java.util.List;
import java.util.Map;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class GameMessage {
    private String type; // NUMBER_CALLED | PRIZE_WON | GAME_STATUS | GAME_STARTING | COUNTDOWN
    private GameStatus gameStatus;

    // For NUMBER_CALLED
    private Integer calledNumber;
    private Integer callSequence;
    private List<Integer> allCalledNumbers;
    private Integer nextCallInSeconds;

    // For PRIZE_WON
    private Long winnerId;
    private String winnerName;
    private PrizeType prizeType;
    private String prizeDisplayName;
    private Integer prizeAmount;
    private Integer calledNumbersAtWin;

    // For GAME_STATUS
    private Integer currentPlayers;
    private Integer maxPlayers;
    private String message;

    // For COUNTDOWN
    private Integer countdownSeconds;

    // Already-claimed prizes map
    private Map<String, String> claimedPrizes; // prizeType -> winnerName
}
