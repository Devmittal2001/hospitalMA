package com.bingolive.dto.response;

import com.bingolive.enums.GameStatus;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class PrivateContestResponse {
    private Long id;
    private String name;
    private String description;
    private String creatorName;
    private Long creatorId;
    private BigDecimal entryFee;
    private BigDecimal prizePool;
    private int maxPlayers;
    private int currentPlayers;
    private int spotsLeft;
    private int callIntervalSeconds;
    private String inviteCode;
    private String shareUrl;          // Full deep-link: https://bingolive.app/join/BINGO-XK92M
    private String whatsappShareText; // Pre-composed WhatsApp message
    private GameStatus status;
    private boolean publiclyListed;
    private boolean isCreator;        // true if the requesting user created it
    private boolean hasJoined;        // true if requesting user already joined
    private List<PrizeRuleDto> prizeRules;
    private LocalDateTime createdAt;
    private String cardData;          // The requesting user's Housie card (pipe-separated), null if not joined

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PrizeRuleDto {
        private String prizeType;
        private String displayName;
        private int amount;
        private String description;
    }
}
