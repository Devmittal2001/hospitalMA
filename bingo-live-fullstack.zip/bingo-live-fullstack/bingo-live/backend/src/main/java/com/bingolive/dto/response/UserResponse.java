package com.bingolive.dto.response;

import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class UserResponse {
    private Long id;
    private String fullName;
    private String email;
    private String phone;
    private BigDecimal walletBalance;
    private boolean kycVerified;
    private LocalDateTime createdAt;
}
