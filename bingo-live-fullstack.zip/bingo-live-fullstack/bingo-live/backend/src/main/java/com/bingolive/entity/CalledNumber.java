package com.bingolive.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "called_numbers")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CalledNumber {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "contest_id", nullable = false)
    private Contest contest;

    @Column(nullable = false)
    private int number;

    @Column(nullable = false)
    private int callSequence; // 1st called, 2nd called, etc.

    @Column(nullable = false)
    private LocalDateTime calledAt;
}
