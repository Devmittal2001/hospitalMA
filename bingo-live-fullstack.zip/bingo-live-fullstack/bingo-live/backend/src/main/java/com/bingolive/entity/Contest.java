package com.bingolive.entity;

import com.bingolive.enums.GameStatus;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "contests")
@EntityListeners(AuditingEntityListener.class)
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Contest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal prizePool;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal entryFee;

    @Column(nullable = false)
    private int maxPlayers;

    @Column(nullable = false)
    @Builder.Default
    private int currentPlayers = 0;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private GameStatus status = GameStatus.WAITING;

    @Column
    private String badge; // "POPULAR", "FILLING FAST", "NEW"

    @Column
    private String colorHex; // UI accent color

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @Column
    private LocalDateTime startedAt;

    @Column
    private LocalDateTime completedAt;

    @OneToMany(mappedBy = "contest", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<GameParticipant> participants = new ArrayList<>();

    @OneToMany(mappedBy = "contest", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<CalledNumber> calledNumbers = new ArrayList<>();

    @OneToMany(mappedBy = "contest", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<PrizeWin> prizeWins = new ArrayList<>();

    public boolean isFull() {
        return currentPlayers >= maxPlayers;
    }

    public boolean canJoin() {
        return status == GameStatus.WAITING && !isFull();
    }
}
