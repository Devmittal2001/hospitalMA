package com.bingolive.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "game_participants")
@EntityListeners(AuditingEntityListener.class)
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class GameParticipant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore  // ✅ breaks: User → participations → GameParticipant → user → ...
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "contest_id")
    @JsonIgnore  // ✅ breaks: Contest → participants → GameParticipant → contest → ...
    private Contest contest;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "private_contest_id")
    @JsonIgnore  // ✅ breaks: PrivateContest → participants → GameParticipant → privateContest → ...
    private PrivateContest privateContest;

    @Column(nullable = false, length = 200)
    private String cardData;

    @Column(nullable = false)
    @Builder.Default
    private int totalEarnings = 0;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime joinedAt;

    @Transient
    public Long getEffectiveContestId() {
        if (contest != null) return contest.getId();
        if (privateContest != null) return privateContest.getId();
        return null;
    }
}
