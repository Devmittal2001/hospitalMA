package com.bingolive.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Audit log for every join attempt — used for:
 * 1. Brute-force passcode detection (per IP + per contest)
 * 2. Fraud detection (same device joining via multiple accounts)
 * 3. Legal compliance trail
 */
@Entity
@Table(name = "join_attempt_logs",
       indexes = {
           @Index(name = "idx_jal_ip", columnList = "ip_address"),
           @Index(name = "idx_jal_contest", columnList = "contest_id"),
           @Index(name = "idx_jal_user", columnList = "user_id"),
       })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class JoinAttemptLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "contest_id", nullable = false)
    private Long contestId;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "ip_address", nullable = false, length = 45) // IPv4 or IPv6
    private String ipAddress;

    @Column(name = "user_agent", length = 300)
    private String userAgent;

    @Column(nullable = false)
    private boolean success;

    @Column(length = 100)
    private String failReason; // "WRONG_PASSCODE", "CONTEST_FULL", "ALREADY_JOINED", etc.

    @Column(nullable = false)
    private LocalDateTime attemptedAt;
}
