package com.bingolive.entity;

import com.bingolive.enums.GameStatus;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "private_contests")
@EntityListeners(AuditingEntityListener.class)
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PrivateContest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ── Basic info ──────────────────────────────────────────────────────────
    @Column(nullable = false)
    private String name;

    @Column(length = 500)
    private String description;

    // ── Creator ─────────────────────────────────────────────────────────────
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "creator_id", nullable = false)
    private User creator;

    // ── Financial ───────────────────────────────────────────────────────────
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal entryFee;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal prizePool;  // Auto-calculated: entryFee * maxPlayers - platform cut

    @Column(nullable = false)
    @Builder.Default
    private int platformCutPercent = 10; // BingoLive takes 10% of pool

    // ── Contest Settings ────────────────────────────────────────────────────
    @Column(nullable = false)
    private int maxPlayers;

    @Column(nullable = false)
    @Builder.Default
    private int currentPlayers = 0;

    @Column(nullable = false)
    @Builder.Default
    private int numberCallIntervalSeconds = 20;

    // ── Security ─────────────────────────────────────────────────────────────
    @Column(nullable = false, unique = true, length = 12)
    private String inviteCode;   // e.g. "BINGO-XK92M"  — shown in share link

    @Column(nullable = false, length = 60)
    private String passcodeHash; // BCrypt of 6-digit passcode

    @Column(nullable = false)
    @Builder.Default
    private int failedJoinAttempts = 0; // per-contest brute-force counter

    @Column(nullable = false)
    @Builder.Default
    private boolean locked = false;  // locked after 10 failed attempts

    // ── Custom Prize Rules (JSON array stored as text) ───────────────────────
    // Format: [{"type":"FIRST_LINE","amount":50}, ...]
    @Column(nullable = false, columnDefinition = "TEXT")
    private String prizeRulesJson;

    // ── Status ───────────────────────────────────────────────────────────────
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private GameStatus status = GameStatus.WAITING;

    // ── Visibility ───────────────────────────────────────────────────────────
    @Column(nullable = false)
    @Builder.Default
    private boolean publiclyListed = false; // false = invite-only

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @Column
    private LocalDateTime startedAt;

    @Column
    private LocalDateTime completedAt;

    // ── Rate limiting ─────────────────────────────────────────────────────────
    @Column
    private LocalDateTime lockedUntil;

    @OneToMany(mappedBy = "privateContest", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private List<GameParticipant> participants = new ArrayList<>();

    // ── Computed helpers ─────────────────────────────────────────────────────
    public boolean canJoin() {
        return status == GameStatus.WAITING && currentPlayers < maxPlayers && !locked;
    }

    public boolean isFull() {
        return currentPlayers >= maxPlayers;
    }
}
