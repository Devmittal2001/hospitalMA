package com.bingolive.entity;

import com.bingolive.enums.PrizeType;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "prize_wins")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PrizeWin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "contest_id", nullable = false)
    private Contest contest;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PrizeType prizeType;

    @Column(nullable = false)
    private int amount;

    @Column(nullable = false)
    private LocalDateTime wonAt;

    @Column(nullable = false)
    private int calledNumbersAtWin; // How many numbers had been called
}
