package com.bingolive.enums;

public enum GameStatus {
    WAITING,       // Waiting for players to join
    STARTING,      // Countdown before first number
    IN_PROGRESS,   // Game actively running
    COMPLETED,     // All numbers called or full house won
    CANCELLED      // Not enough players
}
