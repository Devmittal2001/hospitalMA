package com.bingolive.enums;

public enum PrizeType {
    EARLY_FIVE(15, "Early Five", "Any 5 numbers marked"),
    FIRST_LINE(10, "1st Line", "Top row complete"),
    SECOND_LINE(10, "2nd Line", "Middle row complete"),
    THIRD_LINE(10, "3rd Line", "Bottom row complete"),
    TOP_HALF(25, "Top Half", "Top two rows complete"),
    FULL_HOUSE(100, "Full House", "All 15 numbers marked");

    private final int prizeAmount;
    private final String displayName;
    private final String description;

    PrizeType(int prizeAmount, String displayName, String description) {
        this.prizeAmount = prizeAmount;
        this.displayName = displayName;
        this.description = description;
    }

    public int getPrizeAmount() { return prizeAmount; }
    public String getDisplayName() { return displayName; }
    public String getDescription() { return description; }
}
