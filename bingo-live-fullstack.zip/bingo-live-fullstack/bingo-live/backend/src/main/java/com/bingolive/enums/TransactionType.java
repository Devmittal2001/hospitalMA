package com.bingolive.enums;

public enum TransactionType {
    DEPOSIT,        // Adding money to wallet
    CONTEST_JOIN,   // Deducted when joining a contest
    PRIZE_CREDIT,   // Won a prize
    WITHDRAWAL,     // Withdraw to bank
    REFUND          // Contest cancelled refund
}
