package com.bingolive.repository;

import com.bingolive.entity.CalledNumber;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CalledNumberRepository extends JpaRepository<CalledNumber, Long> {
    List<CalledNumber> findByContestIdOrderByCallSequenceAsc(Long contestId);
    int countByContestId(Long contestId);
}
