package com.bingolive.repository;

import com.bingolive.entity.Contest;
import com.bingolive.enums.GameStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ContestRepository extends JpaRepository<Contest, Long> {
    List<Contest> findByStatusOrderByCreatedAtDesc(GameStatus status);

    @Query("SELECT c FROM Contest c WHERE c.status IN ('WAITING','IN_PROGRESS','STARTING') ORDER BY c.createdAt DESC")
    List<Contest> findAllActiveContests();

    List<Contest> findByStatusIn(List<GameStatus> statuses);
}
