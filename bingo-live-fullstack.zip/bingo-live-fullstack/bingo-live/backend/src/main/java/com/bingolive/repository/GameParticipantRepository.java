package com.bingolive.repository;

import com.bingolive.entity.GameParticipant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface GameParticipantRepository extends JpaRepository<GameParticipant, Long> {

    // ── Public contests ──
    Optional<GameParticipant> findByUserIdAndContestId(Long userId, Long contestId);
    List<GameParticipant> findByContestId(Long contestId);
    boolean existsByUserIdAndContestId(Long userId, Long contestId);

    // ── Private contests ──
    Optional<GameParticipant> findByUserIdAndPrivateContestId(Long userId, Long privateContestId);
    List<GameParticipant> findByPrivateContestId(Long privateContestId);
    boolean existsByUserIdAndPrivateContestId(Long userId, Long privateContestId);

    List<GameParticipant> findByUserId(Long userId);
}
