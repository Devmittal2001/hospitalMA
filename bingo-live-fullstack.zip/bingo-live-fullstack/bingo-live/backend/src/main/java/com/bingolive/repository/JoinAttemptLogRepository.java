package com.bingolive.repository;

import com.bingolive.entity.JoinAttemptLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

@Repository
public interface JoinAttemptLogRepository extends JpaRepository<JoinAttemptLog, Long> {

    // Count failed attempts from a specific IP for a contest in last N minutes
    @Query("SELECT COUNT(j) FROM JoinAttemptLog j WHERE j.contestId = :contestId " +
           "AND j.ipAddress = :ip AND j.success = false AND j.attemptedAt > :since")
    int countFailedByContestAndIp(@Param("contestId") Long contestId,
                                   @Param("ip") String ip,
                                   @Param("since") LocalDateTime since);

    // Count failed attempts from a specific IP globally in last 15 minutes
    @Query("SELECT COUNT(j) FROM JoinAttemptLog j WHERE j.ipAddress = :ip " +
           "AND j.success = false AND j.attemptedAt > :since")
    int countGlobalFailedByIp(@Param("ip") String ip,
                               @Param("since") LocalDateTime since);

    // Detect same user trying many contests (suspicious bot behaviour)
    @Query("SELECT COUNT(DISTINCT j.contestId) FROM JoinAttemptLog j WHERE j.userId = :userId " +
           "AND j.attemptedAt > :since")
    int countDistinctContestsByUserSince(@Param("userId") Long userId,
                                          @Param("since") LocalDateTime since);
}
