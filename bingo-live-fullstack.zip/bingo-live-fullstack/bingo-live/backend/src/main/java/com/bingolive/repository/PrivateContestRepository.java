package com.bingolive.repository;

import com.bingolive.entity.PrivateContest;
import com.bingolive.enums.GameStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PrivateContestRepository extends JpaRepository<PrivateContest, Long> {

    Optional<PrivateContest> findByInviteCode(String inviteCode);

    List<PrivateContest> findByCreatorIdOrderByCreatedAtDesc(Long creatorId);

    List<PrivateContest> findByPubliclyListedTrueAndStatusOrderByCreatedAtDesc(GameStatus status);

    boolean existsByInviteCode(String inviteCode);

    @Query("SELECT pc FROM PrivateContest pc WHERE pc.creator.id = :userId OR " +
           "EXISTS (SELECT gp FROM GameParticipant gp WHERE gp.privateContest = pc AND gp.user.id = :userId)")
    List<PrivateContest> findAllInvolvedByUserId(@Param("userId") Long userId);
}
