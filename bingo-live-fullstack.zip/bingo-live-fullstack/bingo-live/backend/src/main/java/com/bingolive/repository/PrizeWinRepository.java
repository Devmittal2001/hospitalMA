package com.bingolive.repository;

import com.bingolive.entity.PrizeWin;
import com.bingolive.enums.PrizeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PrizeWinRepository extends JpaRepository<PrizeWin, Long> {
    List<PrizeWin> findByContestId(Long contestId);
    boolean existsByContestIdAndPrizeType(Long contestId, PrizeType prizeType);
    List<PrizeWin> findByUserId(Long userId);
    List<PrizeWin> findByContestIdAndUserId(Long contestId, Long userId);
}
