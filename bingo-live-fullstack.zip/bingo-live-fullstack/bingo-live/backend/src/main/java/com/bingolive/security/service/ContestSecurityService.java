package com.bingolive.security.service;

import com.bingolive.entity.JoinAttemptLog;
import com.bingolive.exception.BusinessException;
import com.bingolive.repository.JoinAttemptLogRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * Central security enforcement for contest joins.
 *
 * Layer 1 — IP rate limiting: max 5 failed passcode attempts per IP per contest per 15 min
 * Layer 2 — Global IP throttle: max 20 failed attempts from any single IP in 15 min
 * Layer 3 — Account velocity check: flag users joining > 10 distinct contests in 5 min
 * Layer 4 — Contest lock: after 10 global failures on a contest, lock it for 30 min
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ContestSecurityService {

    private final JoinAttemptLogRepository logRepo;

    private static final int MAX_FAILURES_PER_IP_PER_CONTEST = 5;
    private static final int MAX_GLOBAL_FAILURES_PER_IP      = 20;
    private static final int MAX_CONTESTS_PER_USER_PER_5_MIN = 10;
    private static final int WINDOW_MINUTES                  = 15;

    /**
     * Call BEFORE checking passcode. Throws BusinessException if blocked.
     */
    public void checkJoinAllowed(Long contestId, Long userId, HttpServletRequest request) {
        String ip = extractIp(request);
        LocalDateTime since = LocalDateTime.now().minusMinutes(WINDOW_MINUTES);

        // Layer 1: IP + contest specific throttle
        int contestFailures = logRepo.countFailedByContestAndIp(contestId, ip, since);
        if (contestFailures >= MAX_FAILURES_PER_IP_PER_CONTEST) {
            log.warn("SECURITY: IP {} blocked from contest {} after {} failures", ip, contestId, contestFailures);
            throw new BusinessException(
                "Too many incorrect passcode attempts. Please wait 15 minutes before trying again.");
        }

        // Layer 2: Global IP throttle (catches distributed contest attacks from one IP)
        int globalFailures = logRepo.countGlobalFailedByIp(ip, since);
        if (globalFailures >= MAX_GLOBAL_FAILURES_PER_IP) {
            log.warn("SECURITY: IP {} globally throttled after {} failures", ip, globalFailures);
            throw new BusinessException(
                "Your IP has been temporarily restricted due to suspicious activity.");
        }

        // Layer 3: Account velocity check
        if (userId != null) {
            int distinctContests = logRepo.countDistinctContestsByUserSince(
                userId, LocalDateTime.now().minusMinutes(5));
            if (distinctContests >= MAX_CONTESTS_PER_USER_PER_5_MIN) {
                log.warn("SECURITY: User {} flagged for bot-like contest velocity: {} contests in 5 min",
                    userId, distinctContests);
                throw new BusinessException(
                    "Unusual activity detected. Your account has been temporarily flagged for review.");
            }
        }
    }

    /**
     * Log a join attempt result for audit and future rate-limit checks.
     */
    public void logAttempt(Long contestId, Long userId, HttpServletRequest request,
                           boolean success, String failReason) {
        String ip = extractIp(request);
        JoinAttemptLog log = JoinAttemptLog.builder()
                .contestId(contestId)
                .userId(userId)
                .ipAddress(ip)
                .userAgent(request.getHeader("User-Agent"))
                .success(success)
                .failReason(failReason)
                .attemptedAt(LocalDateTime.now())
                .build();
        logRepo.save(log);
    }

    /**
     * Extract real client IP — handles proxies, load balancers, Cloudflare.
     */
    public String extractIp(HttpServletRequest request) {
        String[] headers = {
            "X-Forwarded-For", "CF-Connecting-IP", "X-Real-IP",
            "Proxy-Client-IP", "WL-Proxy-Client-IP"
        };
        for (String header : headers) {
            String ip = request.getHeader(header);
            if (ip != null && !ip.isBlank() && !"unknown".equalsIgnoreCase(ip)) {
                return ip.split(",")[0].trim(); // X-Forwarded-For can be comma-separated
            }
        }
        return request.getRemoteAddr();
    }
}
