package com.bingolive.service;

import com.bingolive.enums.PrizeType;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Core Housie/Tambola card generation and prize verification.
 *
 * Card format: 3 rows × 9 columns
 * - Each row has exactly 5 numbers and 4 blanks (0 = blank)
 * - Column 0: 1–9, Column 1: 10–19, …, Column 8: 80–90
 * - Serialized as pipe-separated string: "5|14|0|38|0|56|0|72|81|..."
 *   (27 values total: 3 rows × 9 cols, row-major order)
 */
@Component
public class BingoCardService {

    private static final int ROWS = 3;
    private static final int COLS = 9;
    private static final int NUMBERS_PER_ROW = 5;

    // ─── Card Generation ──────────────────────────────────────────────────────

    public int[][] generateCard() {
        return generateHousieCard(new Random());
    }

    private int[][] generateHousieCard(Random random) {
        int[][] card = new int[ROWS][COLS];

        // Each column covers a numeric range — build a pool per column
        List<List<Integer>> colPools = new ArrayList<>();
        for (int col = 0; col < COLS; col++) {
            int low  = col * 10 + 1;
            int high = (col == 8) ? 90 : (col + 1) * 10;
            List<Integer> pool = new ArrayList<>();
            for (int n = low; n <= high; n++) pool.add(n);
            Collections.shuffle(pool, random);
            colPools.add(pool);
        }

        // Each row: pick 5 random columns to fill, leave others as 0 (blank)
        for (int row = 0; row < ROWS; row++) {
            List<Integer> cols = new ArrayList<>();
            for (int c = 0; c < COLS; c++) cols.add(c);
            Collections.shuffle(cols, random);
            Set<Integer> filledCols = new HashSet<>(cols.subList(0, NUMBERS_PER_ROW));

            for (int col = 0; col < COLS; col++) {
                if (filledCols.contains(col) && !colPools.get(col).isEmpty()) {
                    card[row][col] = colPools.get(col).remove(0);
                } else {
                    card[row][col] = 0; // blank
                }
            }
        }

        return card;
    }

    // ─── Serialization ────────────────────────────────────────────────────────

    public String serializeCard(int[][] card) {
        StringBuilder sb = new StringBuilder();
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                if (row > 0 || col > 0) sb.append('|');
                sb.append(card[row][col]);
            }
        }
        return sb.toString();
    }

    public int[][] deserializeCard(String cardData) {
        String[] parts = cardData.split("\\|");
        int[][] card = new int[ROWS][COLS];
        int idx = 0;
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                card[row][col] = Integer.parseInt(parts[idx++].trim());
            }
        }
        return card;
    }

    // ─── Prize Checking ───────────────────────────────────────────────────────

    /**
     * Check whether a serialized card satisfies a given prize condition.
     * All prize logic is here — single source of truth for both public
     * (GameEngineService) and private (PrivateContestGameEngineExtension) contests.
     */
    public boolean checkPrize(String cardData, Set<Integer> calledNumbers, PrizeType prizeType) {
        int[][] card = deserializeCard(cardData);
        return switch (prizeType) {
            case EARLY_FIVE  -> checkEarlyFive(card, calledNumbers);
            case FIRST_LINE  -> checkRow(card, 0, calledNumbers);
            case SECOND_LINE -> checkRow(card, 1, calledNumbers);
            case THIRD_LINE  -> checkRow(card, 2, calledNumbers);
            case TOP_HALF    -> checkRow(card, 0, calledNumbers) && checkRow(card, 1, calledNumbers);
            case FULL_HOUSE  -> checkFullHouse(card, calledNumbers);
        };
    }

    /**
     * Check prize condition on a pre-deserialized card (avoids repeated parsing
     * when checking multiple prizes in a loop).
     */
    public boolean checkPrizeOnCard(int[][] card, Set<Integer> calledNumbers, PrizeType prizeType) {
        return switch (prizeType) {
            case EARLY_FIVE  -> checkEarlyFive(card, calledNumbers);
            case FIRST_LINE  -> checkRow(card, 0, calledNumbers);
            case SECOND_LINE -> checkRow(card, 1, calledNumbers);
            case THIRD_LINE  -> checkRow(card, 2, calledNumbers);
            case TOP_HALF    -> checkRow(card, 0, calledNumbers) && checkRow(card, 1, calledNumbers);
            case FULL_HOUSE  -> checkFullHouse(card, calledNumbers);
        };
    }

    private boolean checkEarlyFive(int[][] card, Set<Integer> called) {
        int count = 0;
        for (int[] row : card) {
            for (int num : row) {
                if (num > 0 && called.contains(num)) count++;
            }
        }
        return count >= 5;
    }

    /**
     * A row is complete when every non-blank cell in that row has been called.
     * Blank cells (value == 0) are ignored.
     */
    private boolean checkRow(int[][] card, int rowIdx, Set<Integer> called) {
        if (rowIdx < 0 || rowIdx >= ROWS) return false;
        boolean hasNumbers = false;
        for (int num : card[rowIdx]) {
            if (num > 0) {
                hasNumbers = true;
                if (!called.contains(num)) return false; // un-called number found
            }
        }
        return hasNumbers; // only true if row actually had some numbers
    }

    private boolean checkFullHouse(int[][] card, Set<Integer> called) {
        for (int row = 0; row < ROWS; row++) {
            if (!checkRow(card, row, called)) return false;
        }
        return true;
    }

    // ─── Frontend card format helper ──────────────────────────────────────────

    /**
     * Returns all non-blank numbers on the card as a flat set.
     * Used for "is this number on my card?" highlighting in the UI.
     */
    public Set<Integer> getAllNumbers(String cardData) {
        int[][] card = deserializeCard(cardData);
        Set<Integer> nums = new HashSet<>();
        for (int[] row : card) {
            for (int n : row) {
                if (n > 0) nums.add(n);
            }
        }
        return nums;
    }
}
