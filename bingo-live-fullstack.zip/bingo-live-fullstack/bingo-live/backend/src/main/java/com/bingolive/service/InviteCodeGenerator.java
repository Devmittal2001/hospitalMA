package com.bingolive.service;

import org.springframework.stereotype.Component;

import java.security.SecureRandom;

/**
 * Generates cryptographically secure invite codes.
 *
 * Format: BINGO-XXXXX  (5 alphanumeric chars, uppercase, no ambiguous chars)
 * Entropy: 32^5 = 33 million combinations — enough for contest IDs.
 *
 * Excluded chars: 0,O (zero/oh), 1,I,L (one/eye/el) — avoids user confusion.
 */
@Component
public class InviteCodeGenerator {

    private static final String ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ";
    private static final int CODE_LENGTH = 6;
    private static final SecureRandom RANDOM = new SecureRandom();

    public String generate() {
        StringBuilder sb = new StringBuilder("BINGO-");
        for (int i = 0; i < CODE_LENGTH; i++) {
            sb.append(ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length())));
        }
        return sb.toString();
    }

    /**
     * Validates format before any DB lookup — prevents SQL injection via invite code param.
     */
    public boolean isValidFormat(String code) {
        return code != null && code.matches("^BINGO-[23456789ABCDEFGHJKMNPQRSTUVWXYZ]{6}$");
    }
}
