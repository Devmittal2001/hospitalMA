package com.bingolive.service.impl;

import com.bingolive.dto.response.ContestResponse;
import com.bingolive.entity.Contest;
import com.bingolive.enums.GameStatus;
import com.bingolive.repository.ContestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ContestService implements CommandLineRunner {

    private final ContestRepository contestRepository;

    @Override
    public void run(String... args) {
        // Seed default contests on startup
        if (contestRepository.count() == 0) {
            contestRepository.saveAll(Arrays.asList(
                Contest.builder().name("Starter Bingo").prizePool(new BigDecimal("500")).entryFee(new BigDecimal("55")).maxPlayers(10).badge("POPULAR").colorHex("#6C63FF").build(),
                Contest.builder().name("Mid Stakes").prizePool(new BigDecimal("2000")).entryFee(new BigDecimal("220")).maxPlayers(10).badge("").colorHex("#FF6584").build(),
                Contest.builder().name("High Roller").prizePool(new BigDecimal("10000")).entryFee(new BigDecimal("1100")).maxPlayers(10).badge("FILLING FAST").colorHex("#43D39E").build(),
                Contest.builder().name("Mega Bingo").prizePool(new BigDecimal("50000")).entryFee(new BigDecimal("5500")).maxPlayers(10).badge("").colorHex("#FFB547").build(),
                Contest.builder().name("Quick Fire").prizePool(new BigDecimal("200")).entryFee(new BigDecimal("22")).maxPlayers(10).badge("NEW").colorHex("#56CCF2").build()
            ));
        }
    }

    public List<ContestResponse> getAllActiveContests() {
        return contestRepository.findAllActiveContests()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public ContestResponse getById(Long id) {
        return contestRepository.findById(id)
                .map(this::toResponse)
                .orElseThrow(() -> new com.bingolive.exception.BusinessException("Contest not found"));
    }

    private ContestResponse toResponse(Contest c) {
        int spotsLeft = c.getMaxPlayers() - c.getCurrentPlayers();
        double fillPct = (double) c.getCurrentPlayers() / c.getMaxPlayers() * 100;
        return ContestResponse.builder()
                .id(c.getId())
                .name(c.getName())
                .prizePool(c.getPrizePool())
                .entryFee(c.getEntryFee())
                .maxPlayers(c.getMaxPlayers())
                .currentPlayers(c.getCurrentPlayers())
                .status(c.getStatus())
                .badge(c.getBadge())
                .colorHex(c.getColorHex())
                .createdAt(c.getCreatedAt())
                .startedAt(c.getStartedAt())
                .spotsLeft(spotsLeft)
                .fillPercentage(fillPct)
                .build();
    }
}
