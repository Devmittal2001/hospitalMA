package com.bingolive.service.impl;

import com.bingolive.dto.response.GameMessage;
import com.bingolive.entity.*;
import com.bingolive.enums.GameStatus;
import com.bingolive.enums.PrizeType;
import com.bingolive.enums.TransactionType;
import com.bingolive.exception.BusinessException;
import com.bingolive.repository.*;
import com.bingolive.service.BingoCardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class GameEngineService {

    private final ContestRepository contestRepository;
    private final GameParticipantRepository participantRepository;
    private final CalledNumberRepository calledNumberRepository;
    private final PrizeWinRepository prizeWinRepository;
    private final WalletTransactionRepository transactionRepository;
    private final UserRepository userRepository;
    private final BingoCardService cardService;
    private final SimpMessagingTemplate messagingTemplate;

    @Value("${app.game.number-call-interval-seconds:20}")
    private int callIntervalSeconds;

    // Active game state: contestId -> shuffled remaining numbers
    private final Map<Long, Queue<Integer>>   activeGames          = new ConcurrentHashMap<>();
    private final Map<Long, ScheduledFuture<?>> gameTimers         = new ConcurrentHashMap<>();
    private final Map<Long, Set<Integer>>     calledNumbersCache   = new ConcurrentHashMap<>();
    private final ScheduledExecutorService    scheduler            = Executors.newScheduledThreadPool(10);

    // ─── Join Contest ─────────────────────────────────────────────────────────

    @Transactional
    public GameParticipant joinContest(Long userId, Long contestId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new BusinessException("User not found"));
        Contest contest = contestRepository.findById(contestId)
                .orElseThrow(() -> new BusinessException("Contest not found"));

        if (!contest.canJoin())
            throw new BusinessException("Contest is not open for joining");
        if (participantRepository.existsByUserIdAndContestId(userId, contestId))
            throw new BusinessException("Already joined this contest");
        if (user.getWalletBalance().compareTo(contest.getEntryFee()) < 0)
            throw new BusinessException("Insufficient wallet balance");

        // Deduct entry fee
        BigDecimal newBalance = user.getWalletBalance().subtract(contest.getEntryFee());
        user.setWalletBalance(newBalance);
        userRepository.save(user);

        transactionRepository.save(WalletTransaction.builder()
                .user(user).type(TransactionType.CONTEST_JOIN)
                .amount(contest.getEntryFee().negate())
                .balanceAfter(newBalance)
                .description("Joined contest: " + contest.getName())
                .referenceId(contestId)
                .build());

        // Generate Housie card
        int[][] card = cardService.generateCard();
        GameParticipant participant = GameParticipant.builder()
                .user(user).contest(contest)
                .cardData(cardService.serializeCard(card))
                .build();
        participantRepository.save(participant);

        contest.setCurrentPlayers(contest.getCurrentPlayers() + 1);
        contestRepository.save(contest);

        broadcastGameStatus(contest,
                "Player joined! " + (contest.getMaxPlayers() - contest.getCurrentPlayers()) + " spots left.");

        if (contest.isFull()) startCountdown(contestId);

        log.info("User {} joined contest {}", userId, contestId);
        return participant;
    }

    // ─── Countdown ───────────────────────────────────────────────────────────

    @Async
    public void startCountdown(Long contestId) {
        for (int i = 10; i >= 0; i--) {
            final int count = i;
            messagingTemplate.convertAndSend("/topic/game/" + contestId,
                    GameMessage.builder().type("COUNTDOWN").countdownSeconds(count)
                            .message("Game starts in " + count + " seconds!").build());
            try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
        }
        startGame(contestId);
    }

    // ─── Start Game ──────────────────────────────────────────────────────────

    @Transactional
    public void startGame(Long contestId) {
        Contest contest = contestRepository.findById(contestId).orElseThrow();
        if (contest.getStatus() != GameStatus.WAITING && contest.getStatus() != GameStatus.STARTING) return;

        contest.setStatus(GameStatus.IN_PROGRESS);
        contest.setStartedAt(LocalDateTime.now());
        contestRepository.save(contest);

        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 90; i++) numbers.add(i);
        Collections.shuffle(numbers);
        activeGames.put(contestId, new LinkedList<>(numbers));
        calledNumbersCache.put(contestId, new LinkedHashSet<>());

        messagingTemplate.convertAndSend("/topic/game/" + contestId,
                GameMessage.builder().type("GAME_STATUS").gameStatus(GameStatus.IN_PROGRESS)
                        .message("Game started! First number in " + callIntervalSeconds + "s.").build());

        log.info("Game started for contest {}", contestId);

        ScheduledFuture<?> future = scheduler.scheduleAtFixedRate(
                () -> callNextNumber(contestId), callIntervalSeconds, callIntervalSeconds, TimeUnit.SECONDS);
        gameTimers.put(contestId, future);
    }

    // ─── Number Calling ──────────────────────────────────────────────────────

    @Transactional
    public void callNextNumber(Long contestId) {
        try {
            Queue<Integer> remaining = activeGames.get(contestId);
            if (remaining == null || remaining.isEmpty()) { endGame(contestId); return; }

            int number = remaining.poll();
            Set<Integer> called = calledNumbersCache.get(contestId);
            called.add(number);

            Contest contest = contestRepository.findById(contestId).orElseThrow();

            calledNumberRepository.save(CalledNumber.builder()
                    .contest(contest).number(number)
                    .callSequence(called.size())
                    .calledAt(LocalDateTime.now()).build());

            List<Integer> allCalled = new ArrayList<>(called);
            Map<String, String> claimedPrizes = getClaimedPrizesMap(contestId);

            messagingTemplate.convertAndSend("/topic/game/" + contestId,
                    GameMessage.builder()
                            .type("NUMBER_CALLED")
                            .gameStatus(GameStatus.IN_PROGRESS)
                            .calledNumber(number)
                            .callSequence(called.size())
                            .allCalledNumbers(allCalled)
                            .nextCallInSeconds(callIntervalSeconds)
                            .claimedPrizes(claimedPrizes)
                            .build());

            log.info("Contest {} → Called #{}: {}", contestId, called.size(), number);

            // Check prizes AFTER broadcast so clients get the number first
            checkAndAwardPrizes(contestId, called, called.size());

            if (called.size() >= 90) endGame(contestId);

        } catch (Exception e) {
            log.error("Error calling number for contest {}: {}", contestId, e.getMessage(), e);
        }
    }

    // ─── Prize Checking ──────────────────────────────────────────────────────

    @Transactional
    protected void checkAndAwardPrizes(Long contestId, Set<Integer> called, int callCount) {
        List<GameParticipant> participants = participantRepository.findByContestId(contestId);
        Contest contest = contestRepository.findById(contestId).orElseThrow();

        for (PrizeType prizeType : PrizeType.values()) {
            // Skip if already claimed — one winner per prize per public contest
            if (prizeWinRepository.existsByContestIdAndPrizeType(contestId, prizeType)) continue;

            for (GameParticipant participant : participants) {
                // Use BingoCardService.checkPrize as single source of truth
                if (cardService.checkPrize(participant.getCardData(), called, prizeType)) {
                    awardPrize(contest, participant, prizeType, callCount);
                    break; // First winner takes the prize; move to next prize type
                }
            }
        }
    }

    @Transactional
    protected void awardPrize(Contest contest, GameParticipant participant,
                              PrizeType prizeType, int callCount) {
        User winner = participant.getUser();
        int amount = prizeType.getPrizeAmount();

        BigDecimal newBalance = winner.getWalletBalance().add(BigDecimal.valueOf(amount));
        winner.setWalletBalance(newBalance);
        userRepository.save(winner);

        participant.setTotalEarnings(participant.getTotalEarnings() + amount);
        participantRepository.save(participant);

        prizeWinRepository.save(PrizeWin.builder()
                .contest(contest).user(winner).prizeType(prizeType)
                .amount(amount).wonAt(LocalDateTime.now())
                .calledNumbersAtWin(callCount).build());

        transactionRepository.save(WalletTransaction.builder()
                .user(winner).type(TransactionType.PRIZE_CREDIT)
                .amount(BigDecimal.valueOf(amount)).balanceAfter(newBalance)
                .description("Won " + prizeType.getDisplayName() + " in " + contest.getName())
                .referenceId(contest.getId()).build());

        Map<String, String> claimedPrizes = getClaimedPrizesMap(contest.getId());
        claimedPrizes.put(prizeType.name(), winner.getFullName()); // include this new win

        messagingTemplate.convertAndSend("/topic/game/" + contest.getId(),
                GameMessage.builder()
                        .type("PRIZE_WON")
                        .prizeType(prizeType)
                        .prizeDisplayName(prizeType.getDisplayName())
                        .prizeAmount(amount)
                        .winnerId(winner.getId())
                        .winnerName(winner.getFullName())
                        .calledNumbersAtWin(callCount)
                        .claimedPrizes(claimedPrizes)
                        .build());

        log.info("Prize {} won by user {} in contest {}", prizeType, winner.getId(), contest.getId());

        if (prizeType == PrizeType.FULL_HOUSE) endGame(contest.getId());
    }

    // ─── End Game ────────────────────────────────────────────────────────────

    @Transactional
    public void endGame(Long contestId) {
        ScheduledFuture<?> timer = gameTimers.remove(contestId);
        if (timer != null) timer.cancel(false);
        activeGames.remove(contestId);
        calledNumbersCache.remove(contestId);

        Contest contest = contestRepository.findById(contestId).orElseThrow();
        if (contest.getStatus() == GameStatus.COMPLETED) return;

        contest.setStatus(GameStatus.COMPLETED);
        contest.setCompletedAt(LocalDateTime.now());
        contestRepository.save(contest);

        messagingTemplate.convertAndSend("/topic/game/" + contestId,
                GameMessage.builder().type("GAME_STATUS")
                        .gameStatus(GameStatus.COMPLETED)
                        .message("Game over! Thanks for playing.").build());

        log.info("Contest {} completed", contestId);
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private void broadcastGameStatus(Contest contest, String message) {
        messagingTemplate.convertAndSend("/topic/game/" + contest.getId(),
                GameMessage.builder().type("GAME_STATUS")
                        .gameStatus(contest.getStatus())
                        .currentPlayers(contest.getCurrentPlayers())
                        .maxPlayers(contest.getMaxPlayers())
                        .message(message).build());
    }

    private Map<String, String> getClaimedPrizesMap(Long contestId) {
        Map<String, String> map = new LinkedHashMap<>();
        prizeWinRepository.findByContestId(contestId)
                .forEach(pw -> map.put(pw.getPrizeType().name(), pw.getUser().getFullName()));
        return map;
    }

    public List<Integer> getCalledNumbers(Long contestId) {
        return calledNumbersCache.getOrDefault(contestId, new LinkedHashSet<>())
                .stream().collect(Collectors.toList());
    }

    // Called by PrivateContestService for manual start
    public void startPrivateContestCountdown(Long contestId) {
        startCountdown(contestId);
    }
}
