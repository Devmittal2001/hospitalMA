package com.bingolive.service.impl;

import com.bingolive.dto.response.GameMessage;
import com.bingolive.entity.*;
import com.bingolive.enums.GameStatus;
import com.bingolive.enums.TransactionType;
import com.bingolive.repository.*;
import com.bingolive.service.BingoCardService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class PrivateContestGameEngineExtension {

    private final PrivateContestRepository privateContestRepo;
    private final GameParticipantRepository participantRepo;
    private final CalledNumberRepository calledNumberRepo;
    private final UserRepository userRepo;
    private final WalletTransactionRepository txnRepo;
    private final BingoCardService cardService;
    private final SimpMessagingTemplate messagingTemplate;
    private final ObjectMapper objectMapper;

    // ✅ Self-injection: allows @Transactional to work on internally-called methods
    @Autowired
    @Lazy
    private PrivateContestGameEngineExtension self;

    private static final String KEY_PREFIX = "priv-";

    private final Map<String, Queue<Integer>> activeGames = new ConcurrentHashMap<>();
    private final Map<String, ScheduledFuture<?>> gameTimers = new ConcurrentHashMap<>();
    private final Map<String, Set<Integer>> calledCache = new ConcurrentHashMap<>();
    private final Map<String, Set<String>> claimedPrizesCache = new ConcurrentHashMap<>();
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(10);

    // ─────────────────────────────────────────────────────────────
    // COUNTDOWN
    // ─────────────────────────────────────────────────────────────

    @Async
    public void startCountdown(Long privateContestId) {
        String topic = "/topic/private-game/" + privateContestId;
        for (int i = 10; i >= 0; i--) {
            messagingTemplate.convertAndSend(topic, GameMessage.builder()
                    .type("COUNTDOWN")
                    .countdownSeconds(i)
                    .message("Game starts in " + i + " seconds!")
                    .build());
            try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
        }
        self.startGame(privateContestId); // ✅ via proxy so @Transactional is honoured
    }

    // ─────────────────────────────────────────────────────────────
    // START GAME
    // ─────────────────────────────────────────────────────────────

    @Transactional
    public void startGame(Long privateContestId) {
        PrivateContest contest = privateContestRepo.findById(privateContestId).orElseThrow();
        if (contest.getStatus() != GameStatus.WAITING) return;

        contest.setStatus(GameStatus.IN_PROGRESS);
        contest.setStartedAt(LocalDateTime.now());
        privateContestRepo.save(contest);

        String key = KEY_PREFIX + privateContestId;
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= 90; i++) numbers.add(i);
        Collections.shuffle(numbers);
        activeGames.put(key, new LinkedList<>(numbers));
        calledCache.put(key, new LinkedHashSet<>());
        claimedPrizesCache.put(key, new LinkedHashSet<>());

        int interval = contest.getNumberCallIntervalSeconds();
        log.info("Private contest {} started — calling every {}s", contest.getInviteCode(), interval);

        ScheduledFuture<?> future = scheduler.scheduleAtFixedRate(
                () -> self.callNextNumber(privateContestId), // ✅ Spring proxy — @Transactional fires correctly
                interval, interval, TimeUnit.SECONDS);
        gameTimers.put(key, future);
    }

    // ─────────────────────────────────────────────────────────────
    // CALL NEXT NUMBER
    // ─────────────────────────────────────────────────────────────

    @Transactional
    public void callNextNumber(Long privateContestId) {
        try {
            String key = KEY_PREFIX + privateContestId;
            Queue<Integer> remaining = activeGames.get(key);
            if (remaining == null || remaining.isEmpty()) {
                self.endGame(privateContestId);
                return;
            }

            int number = remaining.poll();
            Set<Integer> called = calledCache.get(key);
            called.add(number);

            PrivateContest contest = privateContestRepo.findById(privateContestId).orElseThrow();

            messagingTemplate.convertAndSend("/topic/private-game/" + privateContestId,
                    GameMessage.builder()
                            .type("NUMBER_CALLED")
                            .gameStatus(GameStatus.IN_PROGRESS)
                            .calledNumber(number)
                            .callSequence(called.size())
                            .allCalledNumbers(new ArrayList<>(called))
                            .nextCallInSeconds(contest.getNumberCallIntervalSeconds())
                            .build());

            // ✅ Runs within the same transaction opened by this method's proxy call
            checkAndAwardPrizes(contest, called, called.size());

            if (called.size() >= 90) self.endGame(privateContestId);

        } catch (Exception e) {
            log.error("Error calling number for private contest {}: {}", privateContestId, e.getMessage(), e);
        }
    }

    // ─────────────────────────────────────────────────────────────
    // CHECK & AWARD PRIZES
    // ─────────────────────────────────────────────────────────────

    // No @Transactional needed here — already running inside callNextNumber's transaction
    protected void checkAndAwardPrizes(PrivateContest contest, Set<Integer> called, int callCount) {
        String key = KEY_PREFIX + contest.getId();
        Set<String> claimed = claimedPrizesCache.get(key);
        List<GameParticipant> participants = participantRepo.findByPrivateContestId(contest.getId());
        List<PrizeRuleDto> rules = parseRules(contest.getPrizeRulesJson());

        for (PrizeRuleDto rule : rules) {
            String closedKey = rule.prizeType() + "_CLOSED";
            if (claimed.contains(closedKey)) continue;

            List<GameParticipant> winners = new ArrayList<>();
            for (GameParticipant p : participants) {
                if (checkPrizeCondition(p.getCardData(), called, rule.prizeType())) {
                    winners.add(p);
                }
            }
            if (winners.isEmpty()) continue;

            boolean isSplitPrize = "EARLY_FIVE".equals(rule.prizeType());

            if (isSplitPrize) {
                int splitAmount = rule.amount() / winners.size();
                for (GameParticipant winner : winners) {
                    String winnerKey = rule.prizeType() + "_USER_" + winner.getUser().getId();
                    if (!claimed.contains(winnerKey)) {
                        awardPrize(contest, winner, rule, callCount, splitAmount);
                        claimed.add(winnerKey);
                    }
                }
                claimed.add(closedKey);
            } else {
                if (!claimed.contains(rule.prizeType())) {
                    awardPrize(contest, winners.get(0), rule, callCount, rule.amount());
                    claimed.add(rule.prizeType());
                    claimed.add(closedKey);
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // AWARD PRIZE
    // ─────────────────────────────────────────────────────────────

    // Runs inside callNextNumber's transaction — no separate @Transactional needed
    protected void awardPrize(PrivateContest contest, GameParticipant participant,
                              PrizeRuleDto rule, int callCount, int actualAmount) {
        if (actualAmount <= 0) return;

        // ✅ Re-fetch User by ID — never trust a lazy proxy loaded outside a session
        User winner = userRepo.findById(participant.getUser().getId())
                .orElseThrow(() -> new EntityNotFoundException(
                        "User not found: " + participant.getUser().getId()));

        BigDecimal newBalance = winner.getWalletBalance().add(BigDecimal.valueOf(actualAmount));
        winner.setWalletBalance(newBalance);
        userRepo.save(winner);

        participant.setTotalEarnings(participant.getTotalEarnings() + actualAmount);
        participantRepo.save(participant);

        txnRepo.save(WalletTransaction.builder()
                .user(winner)
                .type(TransactionType.PRIZE_CREDIT)
                .amount(BigDecimal.valueOf(actualAmount))
                .balanceAfter(newBalance)
                .description("Won " + rule.prizeType() + " in " + contest.getName())
                .referenceId(contest.getId())
                .build());

        messagingTemplate.convertAndSend("/topic/private-game/" + contest.getId(),
                GameMessage.builder()
                        .type("PRIZE_WON")
                        .prizeType(safePrizeType(rule.prizeType()))
                        .prizeDisplayName(rule.prizeType())
                        .prizeAmount(actualAmount)
                        .winnerId(winner.getId())
                        .winnerName(winner.getFullName())
                        .calledNumbersAtWin(callCount)
                        .build());

        log.info("Private contest {} — {} ₹{} won by user {}",
                contest.getInviteCode(), rule.prizeType(), actualAmount, winner.getId());

        if ("FULL_HOUSE".equals(rule.prizeType())) self.endGame(contest.getId());
    }

    // ─────────────────────────────────────────────────────────────
    // END GAME
    // ─────────────────────────────────────────────────────────────

    @Transactional
    public void endGame(Long privateContestId) {
        String key = KEY_PREFIX + privateContestId;
        ScheduledFuture<?> timer = gameTimers.remove(key);
        if (timer != null) timer.cancel(false);
        activeGames.remove(key);
        calledCache.remove(key);
        claimedPrizesCache.remove(key);

        PrivateContest contest = privateContestRepo.findById(privateContestId).orElseThrow();
        if (contest.getStatus() == GameStatus.COMPLETED) return;

        contest.setStatus(GameStatus.COMPLETED);
        contest.setCompletedAt(LocalDateTime.now());
        privateContestRepo.save(contest);

        messagingTemplate.convertAndSend("/topic/private-game/" + privateContestId,
                GameMessage.builder()
                        .type("GAME_STATUS")
                        .gameStatus(GameStatus.COMPLETED)
                        .message("Game over!")
                        .build());
    }

    // ─────────────────────────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────────────────────────

    private boolean checkPrizeCondition(String cardData, Set<Integer> called, String prizeType) {
        int[][] card = cardService.deserializeCard(cardData);
        return switch (prizeType) {
            case "EARLY_FIVE"  -> Arrays.stream(card).flatMapToInt(Arrays::stream)
                    .filter(n -> n > 0 && called.contains(n)).count() >= 5;
            case "FIRST_LINE"  -> rowComplete(card[0], called);
            case "SECOND_LINE" -> rowComplete(card[1], called);
            case "THIRD_LINE"  -> rowComplete(card[2], called);
            case "TOP_HALF"    -> rowComplete(card[0], called) && rowComplete(card[1], called);
            case "FULL_HOUSE"  -> rowComplete(card[0], called) && rowComplete(card[1], called)
                    && rowComplete(card[2], called);
            default -> false;
        };
    }

    private boolean rowComplete(int[] row, Set<Integer> called) {
        for (int n : row) if (n > 0 && !called.contains(n)) return false;
        return true;
    }

    private List<PrizeRuleDto> parseRules(String json) {
        try { return objectMapper.readValue(json, new TypeReference<>() {}); }
        catch (Exception e) { return List.of(); }
    }

    private com.bingolive.enums.PrizeType safePrizeType(String s) {
        try { return com.bingolive.enums.PrizeType.valueOf(s); }
        catch (Exception e) { return null; }
    }

    public record PrizeRuleDto(String prizeType, int amount) {}
}
