package com.bingolive.service.impl;

import com.bingolive.dto.request.CreatePrivateContestRequest;
import com.bingolive.dto.request.JoinPrivateContestRequest;
import com.bingolive.dto.response.PrivateContestResponse;
import com.bingolive.entity.*;
import com.bingolive.enums.GameStatus;
import com.bingolive.enums.TransactionType;
import com.bingolive.exception.BusinessException;
import com.bingolive.repository.*;
import com.bingolive.security.service.ContestSecurityService;
import com.bingolive.service.BingoCardService;
import com.bingolive.service.InviteCodeGenerator;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class PrivateContestService {

    private final PrivateContestRepository contestRepo;
    private final UserRepository userRepo;
    private final GameParticipantRepository participantRepo;
    private final WalletTransactionRepository txnRepo;
    private final JoinAttemptLogRepository attemptLogRepo;
    private final BingoCardService cardService;
    private final InviteCodeGenerator codeGen;
    private final PasswordEncoder passwordEncoder;
    private final ContestSecurityService securityService;
    private final ObjectMapper objectMapper;
    private final PrivateContestGameEngineExtension gameEngine;

    @Value("${app.base-url:http://localhost:4200}")
    private String baseUrl;

    // ─── Prize type meta ──────────────────────────────────────────────────────
    private static final Map<String, String[]> PRIZE_META = Map.of(
        "EARLY_FIVE",  new String[]{"Early Five",  "Any 5 numbers marked"},
        "FIRST_LINE",  new String[]{"1st Line",    "Top row complete"},
        "SECOND_LINE", new String[]{"2nd Line",    "Middle row complete"},
        "THIRD_LINE",  new String[]{"3rd Line",    "Bottom row complete"},
        "TOP_HALF",    new String[]{"Top Half",    "Top two rows complete"},
        "FULL_HOUSE",  new String[]{"Full House",  "All 15 numbers marked"}
    );

    // ─── CREATE CONTEST ───────────────────────────────────────────────────────

    @Transactional
    public PrivateContestResponse createContest(Long creatorId,
                                                CreatePrivateContestRequest req) {
        User creator = userRepo.findById(creatorId).orElseThrow();

        // Validate total prize doesn't exceed pool
        int totalPrize = req.getPrizeRules().stream().mapToInt(r -> r.getAmount()).sum();
        BigDecimal pool = req.getEntryFee()
                .multiply(BigDecimal.valueOf(req.getMaxPlayers()))
                .multiply(BigDecimal.valueOf(0.90))  // 10% platform cut
                .setScale(2, RoundingMode.HALF_UP);

        if (BigDecimal.valueOf(totalPrize).compareTo(pool) > 0) {
            throw new BusinessException(
                "Total prize money (₹" + totalPrize + ") exceeds prize pool (₹" + pool + "). " +
                "Reduce prize amounts or increase entry fee.");
        }

        // Generate unique invite code (retry on collision)
        String inviteCode;
        do { inviteCode = codeGen.generate(); }
        while (contestRepo.existsByInviteCode(inviteCode));

        // Serialize prize rules
        String prizeJson;
        try { prizeJson = objectMapper.writeValueAsString(req.getPrizeRules()); }
        catch (Exception e) { throw new BusinessException("Invalid prize rules"); }

        PrivateContest contest = PrivateContest.builder()
                .name(req.getName())
                .description(req.getDescription())
                .creator(creator)
                .entryFee(req.getEntryFee())
                .prizePool(pool)
                .maxPlayers(req.getMaxPlayers())
                .numberCallIntervalSeconds(req.getCallIntervalSeconds())
                .inviteCode(inviteCode)
                .passcodeHash(passwordEncoder.encode(req.getPasscode()))
                .prizeRulesJson(prizeJson)
                .publiclyListed(req.isPubliclyListed())
                .build();

        contestRepo.save(contest);
        log.info("Private contest created: {} by user {}", inviteCode, creatorId);

        // Creator auto-joins their own contest (no fee)
        autoJoinCreator(contest, creator);

        return toResponse(contest, creatorId);
    }

    // ─── JOIN CONTEST ─────────────────────────────────────────────────────────

    @Transactional
    public PrivateContestResponse joinContest(Long userId,
                                              JoinPrivateContestRequest req,
                                              HttpServletRequest httpRequest) {
        // ── Security Layer 1: format validation (blocks injection attacks) ──
        if (!codeGen.isValidFormat(req.getInviteCode().toUpperCase())) {
            throw new BusinessException("Invalid invite code format.");
        }

        String code = req.getInviteCode().toUpperCase().trim();
        PrivateContest contest = contestRepo.findByInviteCode(code)
                .orElseThrow(() -> new BusinessException("Contest not found. Check your invite code."));

        // ── Security Layer 2: rate limiting check ──
        securityService.checkJoinAllowed(contest.getId(), userId, httpRequest);

        // ── Security Layer 3: passcode verify ──
        if (!passwordEncoder.matches(req.getPasscode(), contest.getPasscodeHash())) {
            securityService.logAttempt(contest.getId(), userId, httpRequest, false, "WRONG_PASSCODE");

            // Increment contest-level failure counter
            contest.setFailedJoinAttempts(contest.getFailedJoinAttempts() + 1);
            if (contest.getFailedJoinAttempts() >= 10) {
                contest.setLocked(true);
                contest.setLockedUntil(LocalDateTime.now().plusMinutes(30));
                log.warn("Contest {} LOCKED after 10 failed join attempts", contest.getInviteCode());
            }
            contestRepo.save(contest);

            int attemptsLeft = Math.max(0, 5 - (contest.getFailedJoinAttempts() % 5));
            throw new BusinessException("Incorrect passcode. " + attemptsLeft + " attempts remaining.");
        }

        // ── Security Layer 4: business rule checks ──
        if (contest.isLocked()) {
            throw new BusinessException("This contest is temporarily locked due to too many failed attempts. Try again later.");
        }
        if (!contest.canJoin()) {
            if (contest.isFull()) throw new BusinessException("Contest is full.");
            throw new BusinessException("Contest is no longer accepting players.");
        }
        if (participantRepo.existsByUserIdAndPrivateContestId(userId, contest.getId())) {
            throw new BusinessException("You have already joined this contest.");
        }

        User user = userRepo.findById(userId).orElseThrow();
        if (user.getWalletBalance().compareTo(contest.getEntryFee()) < 0) {
            throw new BusinessException("Insufficient wallet balance. Add ₹" +
                contest.getEntryFee().subtract(user.getWalletBalance()) + " more.");
        }

        // ── Deduct entry fee ──
        BigDecimal newBalance = user.getWalletBalance().subtract(contest.getEntryFee());
        user.setWalletBalance(newBalance);
        userRepo.save(user);

        txnRepo.save(WalletTransaction.builder()
                .user(user).type(TransactionType.CONTEST_JOIN)
                .amount(contest.getEntryFee().negate())
                .balanceAfter(newBalance)
                .description("Joined private contest: " + contest.getName())
                .referenceId(contest.getId())
                .build());

        // ── Generate card & create participant ──
        int[][] card = cardService.generateCard();
        GameParticipant participant = GameParticipant.builder()
                .user(user)
                .privateContest(contest)
                .cardData(cardService.serializeCard(card))
                .build();
        participantRepo.save(participant);

        contest.setCurrentPlayers(contest.getCurrentPlayers() + 1);
        contestRepo.save(contest);

        // ── Log success ──
        securityService.logAttempt(contest.getId(), userId, httpRequest, true, null);

        // ── Auto-start if full ──
        if (contest.isFull()) {
            gameEngine.startCountdown(contest.getId());
        }

        log.info("User {} joined private contest {}", userId, contest.getInviteCode());
        return toResponse(contest, userId);
    }

    // ─── LOOK UP by invite code (for the join page) ───────────────────────────

    public PrivateContestResponse getByInviteCode(String code, Long requestingUserId) {
        if (!codeGen.isValidFormat(code.toUpperCase())) {
            throw new BusinessException("Invalid invite code format.");
        }
        PrivateContest contest = contestRepo.findByInviteCode(code.toUpperCase())
                .orElseThrow(() -> new BusinessException("Contest not found."));
        return toResponse(contest, requestingUserId);
    }

    // ─── LOOK UP by numeric ID (for the game page) ─────────────────────────────

    public PrivateContestResponse getById(Long contestId, Long requestingUserId) {
        PrivateContest contest = contestRepo.findById(contestId)
                .orElseThrow(() -> new BusinessException("Contest not found."));
        return toResponse(contest, requestingUserId);
    }

    // ─── My Contests ─────────────────────────────────────────────────────────

    public List<PrivateContestResponse> getMyContests(Long userId) {
        return contestRepo.findAllInvolvedByUserId(userId)
                .stream().map(c -> toResponse(c, userId))
                .collect(Collectors.toList());
    }

    // ─── Creator starts the game manually ────────────────────────────────────

    @Transactional
    public void startNow(Long contestId, Long requestingUserId) {
        PrivateContest contest = contestRepo.findById(contestId).orElseThrow();
        if (!contest.getCreator().getId().equals(requestingUserId)) {
            throw new BusinessException("Only the contest creator can start the game.");
        }
        if (contest.getCurrentPlayers() < 2) {
            throw new BusinessException("Need at least 2 players to start.");
        }
        if (contest.getStatus() != GameStatus.WAITING) {
            throw new BusinessException("Contest is already " + contest.getStatus());
        }
        gameEngine.startCountdown(contestId);
    }

    // ─── Creator auto-join (no fee) ───────────────────────────────────────────

    private void autoJoinCreator(PrivateContest contest, User creator) {
        int[][] card = cardService.generateCard();
        participantRepo.save(GameParticipant.builder()
                .user(creator)
                .privateContest(contest)
                .cardData(cardService.serializeCard(card))
                .build());
        contest.setCurrentPlayers(1);
        contestRepo.save(contest);
    }

    // ─── Response mapper ──────────────────────────────────────────────────────

    private PrivateContestResponse toResponse(PrivateContest c, Long requestingUserId) {
        List<PrivateContestResponse.PrizeRuleDto> rules = parsePrizeRules(c.getPrizeRulesJson());
        String shareUrl = baseUrl + "/join/" + c.getInviteCode();
        String waText   = buildWhatsAppText(c, shareUrl);

        // Fetch this specific user's card data, if they've joined.
        // Without this, the frontend has no card to render after a page refresh
        // or when loading the game page directly (vs. via in-memory nav state).
        String myCardData = requestingUserId == null ? null :
                participantRepo.findByUserIdAndPrivateContestId(requestingUserId, c.getId())
                        .map(GameParticipant::getCardData)
                        .orElse(null);

        return PrivateContestResponse.builder()
                .id(c.getId())
                .name(c.getName())
                .description(c.getDescription())
                .creatorName(c.getCreator().getFullName())
                .creatorId(c.getCreator().getId())
                .entryFee(c.getEntryFee())
                .prizePool(c.getPrizePool())
                .maxPlayers(c.getMaxPlayers())
                .currentPlayers(c.getCurrentPlayers())
                .spotsLeft(c.getMaxPlayers() - c.getCurrentPlayers())
                .callIntervalSeconds(c.getNumberCallIntervalSeconds())
                .inviteCode(c.getInviteCode())
                .shareUrl(shareUrl)
                .whatsappShareText(waText)
                .status(c.getStatus())
                .publiclyListed(c.isPubliclyListed())
                .isCreator(c.getCreator().getId().equals(requestingUserId))
                .hasJoined(requestingUserId != null &&
                        participantRepo.existsByUserIdAndPrivateContestId(requestingUserId, c.getId()))
                .prizeRules(rules)
                .createdAt(c.getCreatedAt())
                .cardData(myCardData)
                .build();
    }

    private List<PrivateContestResponse.PrizeRuleDto> parsePrizeRules(String json) {
        try {
            List<CreatePrivateContestRequest.PrizeRuleDto> raw =
                objectMapper.readValue(json, new TypeReference<>() {});
            return raw.stream().map(r -> {
                String[] meta = PRIZE_META.getOrDefault(r.getPrizeType(), new String[]{r.getPrizeType(), ""});
                return PrivateContestResponse.PrizeRuleDto.builder()
                        .prizeType(r.getPrizeType())
                        .displayName(meta[0])
                        .amount(r.getAmount())
                        .description(meta[1])
                        .build();
            }).collect(Collectors.toList());
        } catch (Exception e) { return List.of(); }
    }

    private String buildWhatsAppText(PrivateContest c, String url) {
        return String.format(
            "🎱 *You're invited to play BingoLive!*\n\n" +
            "Contest: *%s*\n" +
            "Entry Fee: ₹%s | Prize Pool: ₹%s\n" +
            "Players: %d/%d\n\n" +
            "👉 Join here: %s\n" +
            "🔑 Invite Code: *%s*\n\n" +
            "_Ask the host for the passcode!_",
            c.getName(), c.getEntryFee(), c.getPrizePool(),
            c.getCurrentPlayers(), c.getMaxPlayers(),
            url, c.getInviteCode()
        );
    }
}
