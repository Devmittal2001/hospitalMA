package com.bingolive.service.impl;

import com.bingolive.entity.User;
import com.bingolive.entity.WalletTransaction;
import com.bingolive.enums.TransactionType;
import com.bingolive.exception.BusinessException;
import com.bingolive.repository.UserRepository;
import com.bingolive.repository.WalletTransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class WalletService {

    private final UserRepository userRepository;
    private final WalletTransactionRepository transactionRepository;

    @Transactional
    public BigDecimal addFunds(Long userId, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.valueOf(10)) < 0) {
            throw new BusinessException("Minimum deposit is ₹10");
        }
        User user = userRepository.findById(userId).orElseThrow();
        BigDecimal newBalance = user.getWalletBalance().add(amount);
        user.setWalletBalance(newBalance);
        userRepository.save(user);

        WalletTransaction txn = WalletTransaction.builder()
                .user(user)
                .type(TransactionType.DEPOSIT)
                .amount(amount)
                .balanceAfter(newBalance)
                .description("Wallet top-up")
                .build();
        transactionRepository.save(txn);

        return newBalance;
    }

    public List<WalletTransaction> getHistory(Long userId) {
        return transactionRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public BigDecimal getBalance(Long userId) {
        return userRepository.findById(userId)
                .map(User::getWalletBalance)
                .orElseThrow(() -> new BusinessException("User not found"));
    }
}
