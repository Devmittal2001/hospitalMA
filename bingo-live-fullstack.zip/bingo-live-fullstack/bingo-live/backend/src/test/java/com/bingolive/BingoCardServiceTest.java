package com.bingolive;

import com.bingolive.enums.PrizeType;
import com.bingolive.service.BingoCardService;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class BingoCardServiceTest {

    private final BingoCardService cardService = new BingoCardService();

    @Test
    void generatedCard_hasExactlyFiveNumbersPerRow() {
        int[][] card = cardService.generateCard();
        for (int[] row : card) {
            long count = 0;
            for (int v : row) if (v > 0) count++;
            assertEquals(5, count, "Each row must have exactly 5 numbers");
        }
    }

    @Test
    void serializeAndDeserialize_roundTrips() {
        int[][] original = cardService.generateCard();
        String serialized = cardService.serializeCard(original);
        int[][] restored = cardService.deserializeCard(serialized);
        assertArrayEquals(original, restored);
    }

    @Test
    void fullHouse_requiresAllNumbersCalled() {
        int[][] card = cardService.generateCard();
        String data = cardService.serializeCard(card);

        Set<Integer> called = new HashSet<>();
        for (int[] row : card) for (int v : row) if (v > 0) called.add(v);

        assertTrue(cardService.checkPrize(data, called, PrizeType.FULL_HOUSE));

        called.remove(called.iterator().next());
        assertFalse(cardService.checkPrize(data, called, PrizeType.FULL_HOUSE));
    }

    @Test
    void earlyFive_triggersAtFiveMarks() {
        int[][] card = cardService.generateCard();
        String data = cardService.serializeCard(card);

        Set<Integer> called = new HashSet<>();
        int count = 0;
        for (int[] row : card) {
            for (int v : row) {
                if (v > 0 && count < 5) { called.add(v); count++; }
            }
        }
        assertTrue(cardService.checkPrize(data, called, PrizeType.EARLY_FIVE));
    }

    @Test
    void firstLine_requiresOnlyTopRow() {
        int[][] card = cardService.generateCard();
        String data = cardService.serializeCard(card);

        Set<Integer> called = new HashSet<>();
        for (int v : card[0]) if (v > 0) called.add(v);

        assertTrue(cardService.checkPrize(data, called, PrizeType.FIRST_LINE));
        assertFalse(cardService.checkPrize(data, called, PrizeType.SECOND_LINE));
    }
}
