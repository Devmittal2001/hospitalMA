import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { guestGuard } from './core/guards/guest.guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'lobby',
    pathMatch: 'full',
  },
  {
    path: 'login',
    loadComponent: () => import('./features/auth/login/login.component').then(m => m.LoginComponent),
    canActivate: [guestGuard],
  },
  {
    path: 'register',
    loadComponent: () => import('./features/auth/register/register.component').then(m => m.RegisterComponent),
    canActivate: [guestGuard],
  },
  {
    path: 'lobby',
    loadComponent: () => import('./features/lobby/lobby.component').then(m => m.LobbyComponent),
    canActivate: [authGuard],
  },
  {
    path: 'game/:contestId',
    loadComponent: () => import('./features/game/game.component').then(m => m.GameComponent),
    canActivate: [authGuard],
  },
  {
    path: 'wallet',
    loadComponent: () => import('./features/wallet/wallet.component').then(m => m.WalletComponent),
    canActivate: [authGuard],
  },
  {
    path: 'create-contest',
    loadComponent: () => import('./features/create-contest/create-contest.component').then(m => m.CreateContestComponent),
    canActivate: [authGuard],
  },
  {
    path: 'contest-created',
    loadComponent: () => import('./features/create-contest/contest-created.component').then(m => m.ContestCreatedComponent),
    canActivate: [authGuard],
  },
  {
    path: 'join',
    loadComponent: () => import('./features/join-contest/join-contest.component').then(m => m.JoinContestComponent),
    canActivate: [authGuard],
  },
  // Deep link: /join/BINGO-XXXXX (from WhatsApp share)
  {
    path: 'join/:inviteCode',
    loadComponent: () => import('./features/join-contest/join-contest.component').then(m => m.JoinContestComponent),
    canActivate: [authGuard],
  },
  {
    path: '**',
    redirectTo: 'lobby',
  },
];
