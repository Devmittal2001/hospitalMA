import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Contest } from '../../shared/models';
import { environment } from '../../../environments/environment';

export interface JoinContestResponse {
  message: string;
  cardData: string;
  participantId: number;
}

@Injectable({ providedIn: 'root' })
export class ContestService {
  constructor(private http: HttpClient) {}

  getActiveContests(): Observable<Contest[]> {
    return this.http.get<Contest[]>(`${environment.apiUrl}/contests`);
  }

  getContest(id: number): Observable<Contest> {
    return this.http.get<Contest>(`${environment.apiUrl}/contests/${id}`);
  }

  joinContest(contestId: number): Observable<JoinContestResponse> {
    return this.http.post<JoinContestResponse>(`${environment.apiUrl}/contests/${contestId}/join`, {});
  }

  getCalledNumbers(contestId: number): Observable<number[]> {
    return this.http.get<number[]>(`${environment.apiUrl}/contests/${contestId}/called-numbers`);
  }
}
