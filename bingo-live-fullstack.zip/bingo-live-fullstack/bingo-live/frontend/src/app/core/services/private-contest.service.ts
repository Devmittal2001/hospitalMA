import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface PrivateContestResponse {
  id: number;
  name: string;
  description: string;
  creatorName: string;
  creatorId: number;
  entryFee: number;
  prizePool: number;
  maxPlayers: number;
  currentPlayers: number;
  spotsLeft: number;
  callIntervalSeconds: number;
  inviteCode: string;
  shareUrl: string;
  whatsappShareText: string;
  status: 'WAITING' | 'STARTING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  publiclyListed: boolean;
  isCreator: boolean;
  hasJoined: boolean;
  prizeRules: { prizeType: string; displayName: string; amount: number; description: string }[];
  createdAt: string;
  cardData: string | null;
}

@Injectable({ providedIn: 'root' })
export class PrivateContestService {
  constructor(private http: HttpClient) {}

  /** Look up a private contest's current state by its numeric ID (used on the game page). */
  getById(id: number): Observable<PrivateContestResponse> {
    return this.http.get<PrivateContestResponse>(`${environment.apiUrl}/private-contests/${id}`);
  }

  /** Look up by invite code (used on the join page, before the user has joined). */
  lookupByCode(inviteCode: string): Observable<PrivateContestResponse> {
    return this.http.get<PrivateContestResponse>(`${environment.apiUrl}/private-contests/lookup/${inviteCode}`);
  }

  join(inviteCode: string, passcode: string): Observable<PrivateContestResponse> {
    return this.http.post<PrivateContestResponse>(`${environment.apiUrl}/private-contests/join`, {
      inviteCode, passcode,
    });
  }

  getMyContests(): Observable<PrivateContestResponse[]> {
    return this.http.get<PrivateContestResponse[]>(`${environment.apiUrl}/private-contests/my`);
  }

  startNow(contestId: number): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${environment.apiUrl}/private-contests/${contestId}/start`, {});
  }
}
