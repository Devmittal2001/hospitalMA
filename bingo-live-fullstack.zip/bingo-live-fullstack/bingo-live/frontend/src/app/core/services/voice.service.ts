import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class VoiceService {
  private synth: SpeechSynthesis;
  private enabled = true;
  private voice: SpeechSynthesisVoice | null = null;
  private queue: string[] = [];
  private speaking = false;

  // Housie-style nickname map for special numbers
  private readonly nicknames: Record<number, string> = {
    1:  'Kelly\'s Eye, number 1',
    2:  'One Little Duck, number 2',
    7:  'Lucky Seven',
    8:  'One Fat Lady, number 8',
    9:  'Doctor\'s Orders, number 9',
    10: 'Theresa\'s Den, number 10',
    11: 'Legs Eleven',
    13: 'Unlucky for some, 13',
    21: 'Key of the Door, 21',
    22: 'Two Little Ducks, 22',
    33: 'All the Threes, 33',
    44: 'Droopy Drawers, 44',
    55: 'Snakes Alive, 55',
    66: 'Clickety Click, 66',
    69: 'Either Way Up, 69',
    77: 'Sunset Strip, 77',
    88: 'Two Fat Ladies, 88',
    90: 'Top of the Shop, 90',
  };

  constructor() {
    this.synth = window.speechSynthesis;
    this.loadVoice();
  }

  private loadVoice(): void {
    const tryLoad = () => {
      const voices = this.synth.getVoices();
      // Prefer Indian English or any English voice
      this.voice =
        voices.find(v => v.lang === 'en-IN') ||
        voices.find(v => v.lang.startsWith('en-') && v.name.toLowerCase().includes('female')) ||
        voices.find(v => v.lang.startsWith('en')) ||
        voices[0] ||
        null;
    };
    tryLoad();
    if (this.synth.onvoiceschanged !== undefined) {
      this.synth.onvoiceschanged = tryLoad;
    }
  }

  announceNumber(number: number): void {
    if (!this.enabled) return;
    const text = this.nicknames[number] ?? `Number ${number}`;
    this.enqueue(text);
  }

  announcePrizeWon(prizeName: string, winnerName: string): void {
    if (!this.enabled) return;
    this.enqueue(`Congratulations ${winnerName}! ${prizeName} claimed!`);
  }

  announceGameStart(): void {
    if (!this.enabled) return;
    this.enqueue('Eyes down! The game is about to begin. Good luck everyone!');
  }

  announceCountdown(seconds: number): void {
    if (!this.enabled || seconds > 5 || seconds === 0) return;
    this.enqueue(String(seconds));
  }

  announceGameOver(): void {
    if (!this.enabled) return;
    this.enqueue('Game over! Thank you for playing BingoLive!');
  }

  private enqueue(text: string): void {
    this.queue.push(text);
    if (!this.speaking) this.processQueue();
  }

  private processQueue(): void {
    if (this.queue.length === 0) { this.speaking = false; return; }
    this.speaking = true;
    const text = this.queue.shift()!;
    const utterance = new SpeechSynthesisUtterance(text);
    if (this.voice) utterance.voice = this.voice;
    utterance.rate  = 0.9;
    utterance.pitch = 1.1;
    utterance.volume = 1.0;
    utterance.onend = () => this.processQueue();
    utterance.onerror = () => this.processQueue();
    this.synth.speak(utterance);
  }

  setEnabled(val: boolean): void {
    this.enabled = val;
    if (!val) {
      this.synth.cancel();
      this.queue = [];
      this.speaking = false;
    }
  }

  isEnabled(): boolean { return this.enabled; }

  // Play a short beep using Web Audio API
  playBeep(frequency = 880, duration = 150, type: OscillatorType = 'sine'): void {
    if (!this.enabled) return;
    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = type;
      osc.frequency.value = frequency;
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration / 1000);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + duration / 1000);
    } catch { /* AudioContext may not be available */ }
  }

  playWinSound(): void {
    // Play a little arpeggio
    [523, 659, 784, 1047].forEach((freq, i) => {
      setTimeout(() => this.playBeep(freq, 200, 'triangle'), i * 120);
    });
  }
}
