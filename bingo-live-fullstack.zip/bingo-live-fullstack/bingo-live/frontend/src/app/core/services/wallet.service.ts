import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { WalletTransaction } from '../../shared/models';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class WalletService {
  constructor(private http: HttpClient) {}

  getBalance(): Observable<{ balance: number }> {
    return this.http.get<{ balance: number }>(`${environment.apiUrl}/wallet/balance`);
  }

  addFunds(amount: number): Observable<{ balance: number; message: string }> {
    return this.http.post<{ balance: number; message: string }>(
      `${environment.apiUrl}/wallet/add-funds`,
      { amount }
    );
  }

  getHistory(): Observable<WalletTransaction[]> {
    return this.http.get<WalletTransaction[]>(`${environment.apiUrl}/wallet/history`);
  }
}
