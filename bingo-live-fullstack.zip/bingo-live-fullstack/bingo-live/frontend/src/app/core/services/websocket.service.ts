import { Injectable, OnDestroy } from '@angular/core';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { filter } from 'rxjs/operators';
import { GameMessage } from '../../shared/models';
import { environment } from '../../../environments/environment';

declare const SockJS: any;
declare const Stomp: any;

@Injectable({ providedIn: 'root' })
export class WebSocketService implements OnDestroy {
  private stompClient: any = null;
  private messageSubject = new Subject<GameMessage>();
  private connectionStatus = new BehaviorSubject<'CONNECTING' | 'CONNECTED' | 'DISCONNECTED'>('DISCONNECTED');

  readonly connectionStatus$ = this.connectionStatus.asObservable();

  /**
   * @param contestId   numeric ID of either a public Contest or PrivateContest
   * @param token       JWT for STOMP CONNECT auth header
   * @param isPrivate   true → subscribes to /topic/private-game/{id}
   *                    false → subscribes to /topic/game/{id} (public platform contests)
   */
  connect(contestId: number, token: string, isPrivate = false): void {
    if (this.stompClient?.connected) {
      this.subscribe(contestId, isPrivate);
      return;
    }

    this.connectionStatus.next('CONNECTING');
    const socket = new SockJS(`${environment.wsUrl}/ws`);
    this.stompClient = Stomp.over(socket);
    this.stompClient.debug = null;

    this.stompClient.connect(
      { Authorization: `Bearer ${token}` },
      () => {
        this.connectionStatus.next('CONNECTED');
        this.subscribe(contestId, isPrivate);
      },
      (error: any) => {
        console.error('WebSocket error:', error);
        this.connectionStatus.next('DISCONNECTED');
        setTimeout(() => this.connect(contestId, token, isPrivate), 3000);
      }
    );
  }

  private subscribe(contestId: number, isPrivate: boolean): void {
    const topic = isPrivate ? `/topic/private-game/${contestId}` : `/topic/game/${contestId}`;
    this.stompClient.subscribe(topic, (frame: any) => {
      try {
        const message: GameMessage = JSON.parse(frame.body);
        this.messageSubject.next(message);
      } catch (e) {
        console.error('Failed to parse WS message:', e);
      }
    });
  }

  getMessages(): Observable<GameMessage> {
    return this.messageSubject.asObservable();
  }

  getMessagesOfType(...types: GameMessage['type'][]): Observable<GameMessage> {
    return this.messageSubject.pipe(filter(msg => types.includes(msg.type)));
  }

  disconnect(): void {
    if (this.stompClient?.connected) this.stompClient.disconnect();
    this.connectionStatus.next('DISCONNECTED');
    this.stompClient = null;
  }

  ngOnDestroy(): void { this.disconnect(); }
}
