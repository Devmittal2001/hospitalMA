import { Component, signal } from '@angular/core';
import { CommonModule }      from '@angular/common';
import { FormsModule }       from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService }       from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="auth-wrap">
      <div class="auth-left">
        <div class="al-brand">
          <div class="al-icon">🎱</div>
          <div class="al-name">BingoLive</div>
        </div>
        <h1 class="al-headline">Win Real Money<br>Playing Bingo</h1>
        <p class="al-sub">Live contests. Instant payouts. Voice announcements.</p>
        <div class="al-features">
          <div class="alf">✅ Numbers called every 20 seconds</div>
          <div class="alf">✅ 6 prize categories per contest</div>
          <div class="alf">✅ Instant wallet credit on win</div>
          <div class="alf">✅ ₹500 welcome bonus on signup</div>
        </div>
      </div>

      <div class="auth-right">
        <div class="auth-card">
          <h2 class="ac-title">Sign In</h2>
          <p class="ac-sub">Welcome back! Enter your details below.</p>

          <div class="field">
            <label>Email Address</label>
            <input type="email" [(ngModel)]="email" placeholder="you@email.com" />
          </div>
          <div class="field">
            <label>Password</label>
            <input type="password" [(ngModel)]="password" placeholder="Your password" />
          </div>

          @if (error()) {
            <div class="err-box">⚠ {{ error() }}</div>
          }

          <button class="btn-submit" (click)="submit()" [disabled]="loading()">
            {{ loading() ? 'Signing in…' : 'Sign In →' }}
          </button>

          <div class="switch-line">
            New here? <a routerLink="/register">Create a free account</a>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-wrap {
      min-height: 100vh; display: flex; font-family: 'Inter', sans-serif;
    }
    .auth-left {
      flex: 1; background: linear-gradient(155deg, #0F7A48 0%, #1DB971 60%, #34C785 100%);
      padding: 60px 56px; display: flex; flex-direction: column; justify-content: center;
      color: #fff;
    }
    .al-brand { display: flex; align-items: center; gap: 12px; margin-bottom: 40px; }
    .al-icon  { font-size: 36px; }
    .al-name  { font-family:'Nunito',sans-serif; font-size: 26px; font-weight: 900; }
    .al-headline { font-family:'Nunito',sans-serif; font-size: 44px; font-weight: 900; line-height: 1.15; margin-bottom: 16px; }
    .al-sub  { font-size: 17px; color: rgba(255,255,255,.8); margin-bottom: 36px; }
    .al-features { display: flex; flex-direction: column; gap: 12px; }
    .alf { font-size: 15px; color: rgba(255,255,255,.9); }

    .auth-right {
      width: 480px; background: var(--bg);
      display: flex; align-items: center; justify-content: center; padding: 40px;
    }
    .auth-card {
      background: var(--white); border-radius: var(--radius-xl); padding: 44px 40px;
      box-shadow: var(--shadow-lg); width: 100%;
    }
    .ac-title { font-family:'Nunito',sans-serif; font-size: 28px; font-weight: 900; color: var(--text-1); margin-bottom: 6px; }
    .ac-sub   { color: var(--text-3); font-size: 14px; margin-bottom: 28px; }

    .field { margin-bottom: 18px; }
    label  { display: block; font-size: 13px; font-weight: 600; color: var(--text-2); margin-bottom: 6px; }
    input  {
      width: 100%; padding: 13px 16px; border: 1.5px solid var(--border);
      border-radius: var(--radius-md); font-size: 15px; color: var(--text-1);
      background: var(--surface); outline: none; transition: border .2s; box-sizing: border-box;
      &:focus { border-color: var(--green-500); box-shadow: 0 0 0 3px rgba(29,185,113,.12); }
    }
    .err-box {
      background: var(--red-light); color: var(--red); border: 1px solid #FECACA;
      border-radius: var(--radius-md); padding: 11px 14px; font-size: 13px; margin-bottom: 14px;
    }
    .btn-submit {
      width: 100%; padding: 14px; border: none; border-radius: var(--radius-md);
      background: var(--green-500); color: #fff; font-size: 16px; font-weight: 800;
      font-family: 'Nunito', sans-serif; margin-top: 4px; cursor: pointer;
      &:hover:not(:disabled) { background: var(--green-600); }
      &:disabled { opacity: .6; cursor: not-allowed; }
    }
    .switch-line {
      text-align: center; margin-top: 18px; font-size: 14px; color: var(--text-3);
      a { color: var(--green-600); font-weight: 700; text-decoration: none; }
    }
    @media (max-width: 768px) {
      .auth-left { display: none; }
      .auth-right { width: 100%; }
    }
  `]
})
export class LoginComponent {
  email = ''; password = '';
  loading = signal(false);
  error   = signal('');

  constructor(private auth: AuthService, private router: Router) {}

  submit() {
    this.error.set('');
    this.loading.set(true);
    this.auth.login({ email: this.email, password: this.password }).subscribe({
      next: () => this.router.navigate(['/lobby']),
      error: e => { this.error.set(e?.error?.message ?? 'Login failed'); this.loading.set(false); }
    });
  }
}
