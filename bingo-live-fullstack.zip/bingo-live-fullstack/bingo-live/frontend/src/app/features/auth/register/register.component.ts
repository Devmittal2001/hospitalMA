import { Component, signal } from '@angular/core';
import { CommonModule }      from '@angular/common';
import { FormsModule }       from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService }       from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="auth-page">
      <div class="auth-card">
        <div class="logo-block">
          <span class="logo-icon">🎱</span>
          <h1 class="logo-text">BingoLive</h1>
          <p class="logo-sub">₹500 welcome bonus on signup!</p>
        </div>

        <form (ngSubmit)="onSubmit()" class="auth-form">
          <h2>Create Account</h2>

          <div class="field">
            <label>Full Name</label>
            <input type="text" [(ngModel)]="form.fullName" name="fullName" placeholder="Rahul Sharma" required />
          </div>
          <div class="field">
            <label>Email Address</label>
            <input type="email" [(ngModel)]="form.email" name="email" placeholder="you@email.com" required />
          </div>
          <div class="field">
            <label>Mobile Number</label>
            <div class="phone-row">
              <span class="phone-prefix">+91</span>
              <input type="tel" [(ngModel)]="form.phone" name="phone" placeholder="9876543210" maxlength="10" required />
            </div>
          </div>
          <div class="field">
            <label>Password</label>
            <input type="password" [(ngModel)]="form.password" name="password" placeholder="Min 6 characters" required />
          </div>

          @if (error()) {
            <div class="error-msg">⚠ {{ error() }}</div>
          }

          <button type="submit" class="btn-primary" [disabled]="loading()">
            {{ loading() ? 'Creating account…' : 'Create Account →' }}
          </button>

          <p class="switch-link">
            Already have an account? <a routerLink="/login">Sign In</a>
          </p>
          <p class="terms">By continuing, you agree to our Terms of Service. Must be 18+.</p>
        </form>
      </div>
    </div>
  `,
  styles: [`
    .auth-page { min-height:100vh; background:linear-gradient(135deg,#0A0B1E,#111236,#0D0E24);
      display:flex; align-items:center; justify-content:center; padding:24px; }
    .auth-card { width:100%; max-width:440px; background:rgba(255,255,255,.04);
      border:1px solid rgba(255,255,255,.08); border-radius:20px; padding:40px;
      box-shadow:0 24px 80px rgba(108,99,255,.15); }
    .logo-block { text-align:center; margin-bottom:28px; }
    .logo-icon { font-size:44px; }
    .logo-text { font-size:28px; font-weight:900; margin:8px 0 4px;
      background:linear-gradient(90deg,#6C63FF,#FF6584,#43D39E);
      -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
    .logo-sub { color:#43D39E; font-size:13px; margin:0; font-weight:600; }
    h2 { color:#E8E8F0; font-size:20px; margin:0 0 20px; }
    .field { margin-bottom:14px; }
    label { display:block; font-size:13px; color:#888; margin-bottom:5px; font-weight:500; }
    input { width:100%; padding:12px 16px; background:rgba(255,255,255,.06);
      border:1px solid rgba(255,255,255,.12); border-radius:10px;
      color:#E8E8F0; font-size:15px; outline:none; box-sizing:border-box; }
    input:focus { border-color:#6C63FF; }
    .phone-row { display:flex; gap:8px; }
    .phone-prefix { padding:12px 14px; background:rgba(255,255,255,.06);
      border:1px solid rgba(255,255,255,.12); border-radius:10px; color:#888; white-space:nowrap; }
    .phone-row input { flex:1; }
    .error-msg { background:rgba(255,101,132,.08); border:1px solid rgba(255,101,132,.3);
      color:#FF6584; padding:10px 14px; border-radius:8px; font-size:13px; margin-bottom:12px; }
    .btn-primary { width:100%; padding:13px; border:none; border-radius:10px; cursor:pointer;
      background:linear-gradient(135deg,#6C63FF,#8B5CF6); color:#fff; font-size:15px;
      font-weight:700; margin-top:8px; }
    .btn-primary:disabled { opacity:.6; cursor:not-allowed; }
    .switch-link { text-align:center; color:#666; font-size:13px; margin:14px 0 4px; }
    .switch-link a { color:#6C63FF; text-decoration:none; }
    .terms { text-align:center; font-size:11px; color:#444; margin:0; }
  `]
})
export class RegisterComponent {
  form = { fullName:'', email:'', phone:'', password:'' };
  loading = signal(false);
  error   = signal('');

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit(): void {
    this.error.set('');
    const { fullName, email, phone, password } = this.form;
    if (!fullName || !email || !phone || !password) return this.error.set('All fields are required.');
    if (!/^[6-9]\d{9}$/.test(phone)) return this.error.set('Enter a valid 10-digit Indian mobile number.');
    if (password.length < 6) return this.error.set('Password must be at least 6 characters.');

    this.loading.set(true);
    this.auth.register({ fullName, email, phone, password }).subscribe({
      next: () => this.router.navigate(['/lobby']),
      error: (e) => {
        this.error.set(e?.error?.message ?? 'Registration failed. Please try again.');
        this.loading.set(false);
      }
    });
  }
}
