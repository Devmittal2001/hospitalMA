import { Component, OnInit, signal } from '@angular/core';
import { CommonModule }  from '@angular/common';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-contest-created',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page">
      <nav class="nav">
        <div class="brand">🎱 BingoLive</div>
        <button class="btn-lobby" routerLink="/lobby">Go to Lobby</button>
      </nav>

      <div class="body">
        <div class="success-card">
          <div class="sc-icon">🎉</div>
          <h1>Contest Created!</h1>
          <p class="sc-sub">Share the invite link or code with your friends to get them in.</p>

          <!-- Invite Code -->
          <div class="code-box">
            <div class="code-label">Invite Code</div>
            <div class="code-val">{{ contest?.inviteCode }}</div>
            <button class="btn-copy" (click)="copyCode()">{{ codeCopied() ? '✅ Copied!' : '📋 Copy Code' }}</button>
          </div>

          <!-- Share Link -->
          <div class="link-box">
            <div class="link-label">Share Link</div>
            <div class="link-val">{{ contest?.shareUrl }}</div>
            <button class="btn-copy" (click)="copyLink()">{{ linkCopied() ? '✅ Copied!' : '🔗 Copy Link' }}</button>
          </div>

          <!-- WhatsApp Share -->
          <a class="btn-whatsapp" [href]="whatsappHref()" target="_blank">
            <span>💬</span> Share on WhatsApp
          </a>

          <!-- Contest Summary -->
          <div class="summary">
            <div class="s-row"><span>Contest</span><strong>{{ contest?.name }}</strong></div>
            <div class="s-row"><span>Prize Pool</span><strong class="green">₹{{ contest?.prizePool | number }}</strong></div>
            <div class="s-row"><span>Entry Fee</span><strong>₹{{ contest?.entryFee }}</strong></div>
            <div class="s-row"><span>Players</span><strong>{{ contest?.currentPlayers }}/{{ contest?.maxPlayers }}</strong></div>
          </div>

          <!-- Passcode reminder -->
          <div class="passcode-reminder">
            🔑 Remember to share your <strong>passcode separately</strong> — it's not in the link for security.
          </div>

          <div class="actions">
            <button class="btn-play" [routerLink]="['/game', contest?.id]">Enter Game Room →</button>
            <button class="btn-secondary" routerLink="/lobby">Back to Lobby</button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page { min-height: 100vh; background: var(--bg); font-family: 'Inter', sans-serif; }
    .nav {
      background: var(--white); border-bottom: 2px solid var(--green-500);
      padding: 0 32px; height: 60px; display: flex; align-items: center; justify-content: space-between;
    }
    .brand { font-family:'Nunito',sans-serif; font-size: 20px; font-weight: 900; color: var(--green-600); }
    .btn-lobby { padding: 7px 16px; border-radius: var(--radius-sm); border: 1.5px solid var(--border); background: var(--white); font-size: 13px; color: var(--text-2); font-weight: 600; cursor: pointer; }
    .body { display: flex; justify-content: center; padding: 40px 20px; }
    .success-card {
      background: var(--white); border: 1.5px solid var(--border);
      border-radius: var(--radius-xl); padding: 44px 40px; max-width: 520px; width: 100%;
      text-align: center; box-shadow: var(--shadow-lg);
    }
    .sc-icon { font-size: 56px; margin-bottom: 12px; }
    h1 { font-family:'Nunito',sans-serif; font-size: 30px; font-weight: 900; color: var(--text-1); margin-bottom: 8px; }
    .sc-sub { color: var(--text-3); font-size: 15px; margin-bottom: 28px; }

    .code-box, .link-box {
      background: var(--bg); border: 1.5px solid var(--border); border-radius: var(--radius-md);
      padding: 14px 16px; margin-bottom: 12px; text-align: left;
    }
    .code-label, .link-label { font-size: 11px; font-weight: 700; color: var(--text-3); text-transform: uppercase; letter-spacing: .5px; margin-bottom: 4px; }
    .code-val {
      font-family:'Nunito',sans-serif; font-size: 28px; font-weight: 900;
      color: var(--green-700); letter-spacing: 3px; margin-bottom: 10px;
    }
    .link-val { font-size: 13px; color: var(--text-2); word-break: break-all; margin-bottom: 10px; }
    .btn-copy {
      background: var(--green-50); border: 1.5px solid var(--green-400);
      color: var(--green-700); border-radius: var(--radius-sm);
      padding: 6px 14px; font-size: 13px; font-weight: 700; cursor: pointer;
    }

    .btn-whatsapp {
      display: flex; align-items: center; justify-content: center; gap: 8px;
      background: #25D366; color: #fff;
      border-radius: var(--radius-md); padding: 13px;
      font-size: 15px; font-weight: 800; text-decoration: none;
      margin-bottom: 20px;
      span { font-size: 20px; }
    }

    .summary {
      background: var(--bg); border-radius: var(--radius-md); padding: 14px;
      text-align: left; margin-bottom: 16px;
    }
    .s-row {
      display: flex; justify-content: space-between; align-items: center;
      font-size: 14px; color: var(--text-2); padding: 5px 0;
      border-bottom: 1px solid var(--border);
      &:last-child { border-bottom: none; }
      strong { color: var(--text-1); }
      .green { color: var(--green-600); }
    }

    .passcode-reminder {
      background: #FFFDE7; border: 1.5px solid #FEF08A;
      border-radius: var(--radius-md); padding: 12px 16px;
      font-size: 13px; color: #713F12; text-align: left; margin-bottom: 20px;
    }

    .actions { display: flex; gap: 10px; }
    .btn-play {
      flex: 1; padding: 14px; border: none; border-radius: var(--radius-md);
      background: var(--green-500); color: #fff;
      font-size: 15px; font-weight: 800; font-family: 'Nunito', sans-serif; cursor: pointer;
    }
    .btn-secondary {
      padding: 14px 20px; border: 1.5px solid var(--border); border-radius: var(--radius-md);
      background: var(--white); color: var(--text-2); font-size: 14px; font-weight: 600; cursor: pointer;
    }
  `]
})
export class ContestCreatedComponent implements OnInit {
  contest: any = null;
  codeCopied = signal(false);
  linkCopied = signal(false);

  constructor(private router: Router) {}

  ngOnInit() {
    this.contest = history.state?.contest;
    if (!this.contest) this.router.navigate(['/lobby']);
  }

  copyCode() {
    navigator.clipboard.writeText(this.contest?.inviteCode ?? '');
    this.codeCopied.set(true);
    setTimeout(() => this.codeCopied.set(false), 2500);
  }

  copyLink() {
    navigator.clipboard.writeText(this.contest?.shareUrl ?? '');
    this.linkCopied.set(true);
    setTimeout(() => this.linkCopied.set(false), 2500);
  }

  whatsappHref() {
    const text = encodeURIComponent(this.contest?.whatsappShareText ?? '');
    return `https://wa.me/?text=${text}`;
  }
}
