import { Component, signal, computed } from '@angular/core';
import { CommonModule }   from '@angular/common';
import { FormsModule }    from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpClient }     from '@angular/common/http';
import { AuthService }    from '../../core/services/auth.service';
import { environment }    from '../../../environments/environment';

interface PrizeRule { prizeType: string; amount: number; label: string; desc: string; enabled: boolean; }

@Component({
  selector: 'app-create-contest',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="cc-page">
      <!-- Header -->
      <nav class="nav">
        <div class="nav-brand">
          <span class="brand-icon">🎱</span>
          <span class="brand-name">BingoLive</span>
        </div>
        <button class="btn-back" routerLink="/lobby">← Back to Lobby</button>
      </nav>

      <div class="cc-body">
        <div class="cc-left">

          <!-- Page title -->
          <div class="page-head">
            <h1>🏟️ Create Your Contest</h1>
            <p>Host a private Bingo match with your own rules and invite friends</p>
          </div>

          <!-- Step 1: Basic Info -->
          <div class="form-section">
            <div class="fs-head"><span class="step-num">1</span> Contest Details</div>

            <div class="field">
              <label>Contest Name <span class="req">*</span></label>
              <input [(ngModel)]="form.name" placeholder="e.g. Diwali Bingo Night 🪔" maxlength="60" />
              <span class="field-hint">{{ form.name.length }}/60</span>
            </div>

            <div class="field">
              <label>Description</label>
              <textarea [(ngModel)]="form.description" placeholder="Tell players what this contest is about…" rows="2" maxlength="300"></textarea>
            </div>
          </div>

          <!-- Step 2: Entry & Players -->
          <div class="form-section">
            <div class="fs-head"><span class="step-num">2</span> Entry & Players</div>

            <div class="field-row">
              <div class="field">
                <label>Entry Fee (₹) <span class="req">*</span></label>
                <div class="input-prefix">
                  <span>₹</span>
                  <input type="number" [ngModel]="entryFee()" min="10" max="10000"
                    (ngModelChange)="entryFee.set(+$event)" placeholder="100" />
                </div>
                <span class="field-hint">Min ₹10 · Max ₹10,000</span>
              </div>
              <div class="field">
                <label>Max Players <span class="req">*</span></label>
                <input type="number" [ngModel]="maxPlayers()" min="2" max="50"
                  (ngModelChange)="maxPlayers.set(+$event)" placeholder="10" />
                <span class="field-hint">2–50 players</span>
              </div>
            </div>

            <!-- Pool breakdown -->
            <div class="pool-box">
              <div class="pb-row">
                <span>Total collected</span>
                <span>₹{{ entryFee() * maxPlayers() | number }}</span>
              </div>
              <div class="pb-row">
                <span>Platform fee (10%)</span>
                <span class="red">– ₹{{ (entryFee() * maxPlayers() * 0.10) | number:'1.0-0' }}</span>
              </div>
              <div class="pb-row total">
                <span>Your Prize Pool</span>
                <span class="green">₹{{ prizePool() | number:'1.0-0' }}</span>
              </div>
            </div>

            <div class="field">
              <label>Number Call Speed</label>
              <div class="speed-options">
                @for (s of speeds; track s.val) {
                  <div class="speed-opt" [class.selected]="form.callIntervalSeconds === s.val"
                    (click)="form.callIntervalSeconds = s.val">
                    <div class="so-val">{{ s.val }}s</div>
                    <div class="so-lbl">{{ s.label }}</div>
                  </div>
                }
              </div>
            </div>
          </div>

          <!-- Step 3: Prize Rules -->
          <div class="form-section">
            <div class="fs-head"><span class="step-num">3</span> Prize Rules</div>
            <p class="fs-sub">Enable prizes and set amounts. Total must not exceed ₹{{ prizePool() | number:'1.0-0' }}.</p>

            <div class="prize-rules">
              @for (rule of prizeRules(); track rule.prizeType; let i = $index) {
                <div class="pr-row" [class.pr-enabled]="rule.enabled">
                  <label class="pr-toggle">
                    <input type="checkbox" [checked]="rule.enabled"
                      (change)="toggleRule(i, $any($event.target).checked)" />
                    <span class="pr-toggle-slider"></span>
                  </label>
                  <div class="pr-info">
                    <div class="pr-name">{{ rule.label }}</div>
                    <div class="pr-desc">{{ rule.desc }}</div>
                  </div>
                  <div class="pr-amount-wrap" [class.disabled]="!rule.enabled">
                    <span>₹</span>
                    <input type="number" [value]="rule.amount"
                      [disabled]="!rule.enabled" min="0" max="100000"
                      (input)="updateAmount(i, +$any($event.target).value)" />
                  </div>
                </div>
              }
            </div>

            <!-- Budget tracker -->
            <div class="budget-tracker" [class.over]="isOverBudget()">
              <div class="bt-bar">
                <div class="bt-fill" [style.width.%]="Math.min(100, budgetUsedPct())"></div>
              </div>
              <div class="bt-labels">
                <span>Prizes allocated: ₹{{ totalPrizeAllocated() }}</span>
                <span [class.over]="isOverBudget()">
                  {{ isOverBudget() ? '⚠ Over by ₹' + (totalPrizeAllocated() - prizePool()) : 'Remaining: ₹' + (prizePool() - totalPrizeAllocated()) }}
                </span>
              </div>
            </div>
          </div>

          <!-- Step 4: Security -->
          <div class="form-section">
            <div class="fs-head"><span class="step-num">4</span> Security</div>

            <div class="field-row">
              <div class="field">
                <label>Passcode <span class="req">*</span></label>
                <input type="password" [ngModel]="passcode()" (ngModelChange)="passcode.set($event)"
                  placeholder="4–8 digit code"
                  maxlength="8" pattern="[0-9]*" inputmode="numeric" autocomplete="off" />
                <span class="field-hint">Share this only with trusted players</span>
              </div>
              <div class="field">
                <label>Confirm Passcode <span class="req">*</span></label>
                <input type="password" [ngModel]="confirmPasscode()" (ngModelChange)="confirmPasscode.set($event)"
                  placeholder="Re-enter code"
                  maxlength="8" pattern="[0-9]*" inputmode="numeric" autocomplete="off" />
                <span class="field-hint passcode-match" [class.match]="passcodesMatch()">
                  {{ confirmPasscode() ? (passcodesMatch() ? '✅ Matches' : '❌ No match') : '' }}
                </span>
              </div>
            </div>

            <label class="checkbox-label">
              <input type="checkbox" [(ngModel)]="form.publiclyListed" />
              <span>List publicly in lobby (anyone with wallet can discover and join)</span>
            </label>
          </div>

          <!-- Security Info Box -->
          <div class="security-info">
            <div class="si-title">🔒 How we protect your contest</div>
            <div class="si-items">
              <div class="si-item">🛡️ Passcode is BCrypt-hashed — we never store it in plain text</div>
              <div class="si-item">🚫 Max 5 wrong passcode attempts per IP — auto-lockout after</div>
              <div class="si-item">🔑 Invite code uses cryptographically random generation</div>
              <div class="si-item">📋 Every join attempt is logged with IP + timestamp</div>
              <div class="si-item">⚡ Contest locks automatically after 10 total failed attempts</div>
              <div class="si-item">💰 Entry fees held in escrow — released only on prize claim</div>
            </div>
          </div>

          <!-- Error -->
          @if (error()) {
            <div class="err-box">⚠ {{ error() }}</div>
          }

          <!-- Submit -->
          <button class="btn-create" (click)="create()" [disabled]="loading() || isOverBudget()">
            {{ loading() ? 'Creating Contest…' : '🚀 Create Contest & Get Invite Link' }}
          </button>

        </div>

        <!-- Right: Live Preview -->
        <div class="cc-right">
          <div class="preview-card">
            <div class="preview-badge">Live Preview</div>
            <div class="prev-name">{{ form.name || 'Your Contest Name' }}</div>
            <div class="prev-desc">{{ form.description || 'Contest description will appear here' }}</div>
            <div class="prev-stats">
              <div class="ps-item"><div class="ps-lbl">Prize Pool</div><div class="ps-val green">₹{{ prizePool() | number:'1.0-0' }}</div></div>
              <div class="ps-item"><div class="ps-lbl">Entry Fee</div><div class="ps-val">₹{{ entryFee() }}</div></div>
              <div class="ps-item"><div class="ps-lbl">Players</div><div class="ps-val">0/{{ maxPlayers() }}</div></div>
              <div class="ps-item"><div class="ps-lbl">Call Speed</div><div class="ps-val">{{ form.callIntervalSeconds }}s</div></div>
            </div>
            <div class="prev-prizes">
              <div class="prev-prizes-title">🏆 Prize Rules</div>
              @for (r of enabledRules(); track r.prizeType) {
                <div class="prev-prize-row">
                  <span>{{ r.label }}</span>
                  <span class="ppv">₹{{ r.amount }}</span>
                </div>
              }
              @if (enabledRules().length === 0) {
                <div class="prev-no-prize">Enable prize rules on the left</div>
              }
            </div>
            <div class="prev-security">
              <span>🔒 Passcode protected</span>
              @if (form.publiclyListed) { <span>🌐 Public</span> }
              @else { <span>🔐 Invite only</span> }
            </div>
          </div>

          <!-- Tips -->
          <div class="tips-box">
            <div class="tips-title">💡 Contest Tips</div>
            <div class="tip">Set entry fee based on how serious the group is — ₹50 for friends, ₹500 for office pools</div>
            <div class="tip">Use a memorable passcode like a shared date or PIN that your group knows</div>
            <div class="tip">Enable Full House for the biggest prize — it creates the best finish</div>
            <div class="tip">20–30 second call speed is perfect for most groups</div>
          </div>
        </div>
      </div>
    </div>

    <!-- ── BUDGET WARNING MODAL ────────────────────────────────────────────── -->
    @if (showBudgetWarning()) {
      <div class="modal-backdrop">
        <div class="modal-box">
          <div class="modal-icon">💡</div>
          <h3 class="modal-title">₹{{ remainingAmount() }} Unallocated</h3>
          <p class="modal-body">
            You still have <strong>₹{{ remainingAmount() }}</strong> left in your prize pool
            that hasn't been assigned to any prize. What would you like to do?
          </p>
          <div class="modal-actions">
            <button class="btn-modal-primary" (click)="confirmCreateAnyway()">
              ✅ Distribute equally across prizes
            </button>
            <button class="btn-modal-secondary" (click)="dismissWarningAndCreate()">
              Continue anyway (platform keeps remainder)
            </button>
            <button class="btn-modal-cancel" (click)="showBudgetWarning.set(false)">
              ← Go back and edit
            </button>
          </div>
        </div>
      </div>
    }
  `,
  styleUrls: ['./create-contest.component.scss']
})
export class CreateContestComponent {
  Math = Math;

  // Plain object fields that don't need cross-component reactivity tracking
  form = {
    name: '', description: '',
    callIntervalSeconds: 20,
    publiclyListed: false,
  };

  // Signal-based fields — these feed computed() values, so they MUST be signals
  // for Angular to track changes (reading a plain object property inside a
  // computed() does NOT register as a dependency).
  entryFee        = signal(100);
  maxPlayers      = signal(10);
  passcode        = signal('');
  confirmPasscode = signal('');

  speeds = [
    { val: 10, label: 'Fast' },
    { val: 20, label: 'Normal' },
    { val: 30, label: 'Slow' },
    { val: 45, label: 'Relaxed' },
  ];

  prizeRules = signal<PrizeRule[]>([
    { prizeType: 'EARLY_FIVE',  amount: 0,  label: 'Early Five',  desc: 'Any 5 numbers marked first', enabled: false },
    { prizeType: 'FIRST_LINE',  amount: 0,  label: '1st Line',    desc: 'Top row complete',           enabled: true  },
    { prizeType: 'SECOND_LINE', amount: 0,  label: '2nd Line',    desc: 'Middle row complete',        enabled: false },
    { prizeType: 'THIRD_LINE',  amount: 0,  label: '3rd Line',    desc: 'Bottom row complete',        enabled: false },
    { prizeType: 'TOP_HALF',    amount: 0,  label: 'Top Half',    desc: 'Both top rows complete',     enabled: false },
    { prizeType: 'FULL_HOUSE',  amount: 0,  label: 'Full House',  desc: 'All 15 numbers marked',      enabled: true  },
  ]);

  loading = signal(false);
  error   = signal('');
  showBudgetWarning = signal(false);

  prizePool       = computed(() => Math.floor(this.entryFee() * this.maxPlayers() * 0.9));
  enabledRules    = computed(() => this.prizeRules().filter(r => r.enabled));
  totalPrizeAllocated = computed(() => this.prizeRules().filter(r => r.enabled).reduce((s, r) => s + (Number(r.amount) || 0), 0));
  isOverBudget    = computed(() => this.totalPrizeAllocated() > this.prizePool());
  isUnderBudget   = computed(() => this.totalPrizeAllocated() < this.prizePool() && this.enabledRules().length > 0);
  remainingAmount = computed(() => this.prizePool() - this.totalPrizeAllocated());
  budgetUsedPct   = computed(() => this.prizePool() > 0 ? (this.totalPrizeAllocated() / this.prizePool()) * 100 : 0);
  passcodesMatch  = computed(() => {
    const p1 = this.passcode().trim();
    const p2 = this.confirmPasscode().trim();
    return p1.length >= 4 && p1 === p2;
  });

  toggleRule(index: number, enabled: boolean) {
    this.prizeRules.update(rules => {
      const copy = [...rules];
      copy[index] = { ...copy[index], enabled };
      return copy;
    });
  }

  updateAmount(index: number, amount: number) {
    this.prizeRules.update(rules => {
      const copy = [...rules];
      copy[index] = { ...copy[index], amount: Number(amount) || 0 };
      return copy;
    });
  }

  constructor(private http: HttpClient, private auth: AuthService, private router: Router) {}

  create() {
    this.error.set('');
    if (!this.form.name.trim())       return this.error.set('Contest name is required.');
    if (this.entryFee() < 10)         return this.error.set('Minimum entry fee is ₹10.');
    if (this.maxPlayers() < 2)        return this.error.set('Need at least 2 players.');
    if (!this.passcode().trim().match(/^[0-9]{4,8}$/)) return this.error.set('Passcode must be 4–8 digits.');
    if (!this.passcodesMatch())       return this.error.set('Passcodes do not match.');
    if (this.enabledRules().length === 0) return this.error.set('Enable at least one prize.');
    if (this.isOverBudget())          return this.error.set('Prize total exceeds prize pool. Reduce amounts.');

    // If budget not fully used, warn the host before proceeding
    if (this.isUnderBudget()) {
      this.showBudgetWarning.set(true);
      return;
    }

    this.submitCreate();
  }

  confirmCreateAnyway() {
    // Distribute remaining budget equally across enabled prizes
    const remaining = this.remainingAmount();
    const enabled = this.prizeRules().filter(r => r.enabled);
    if (enabled.length > 0) {
      const bonus = Math.floor(remaining / enabled.length);
      this.prizeRules.update(rules => rules.map(r =>
        r.enabled ? { ...r, amount: r.amount + bonus } : r
      ));
    }
    this.showBudgetWarning.set(false);
    this.submitCreate();
  }

  dismissWarningAndCreate() {
    // Create with the unallocated amount — platform keeps it
    this.showBudgetWarning.set(false);
    this.submitCreate();
  }

  private submitCreate() {
    const body = {
      name:                this.form.name,
      description:         this.form.description,
      entryFee:            this.entryFee(),
      maxPlayers:          this.maxPlayers(),
      callIntervalSeconds: this.form.callIntervalSeconds,
      passcode:            this.passcode().trim(),
      publiclyListed:      this.form.publiclyListed,
      prizeRules:          this.enabledRules().map(r => ({ prizeType: r.prizeType, amount: r.amount })),
    };

    this.loading.set(true);
    this.http.post<any>(`${environment.apiUrl}/private-contests`, body).subscribe({
      next: res => {
        this.loading.set(false);
        this.router.navigate(['/contest-created'], { state: { contest: res } });
      },
      error: e => { this.error.set(e?.error?.message ?? 'Failed to create contest'); this.loading.set(false); }
    });
  }
}
