import { Component, OnInit, OnDestroy, signal, computed } from '@angular/core';
import { CommonModule }     from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Subscription }     from 'rxjs';
import { AuthService }      from '../../core/services/auth.service';
import { ContestService }   from '../../core/services/contest.service';
import { PrivateContestService } from '../../core/services/private-contest.service';
import { WebSocketService } from '../../core/services/websocket.service';
import { VoiceService }     from '../../core/services/voice.service';
import { Contest, GameMessage, PRIZE_DEFINITIONS, PrizeType } from '../../shared/models';

interface CardCell { value: number | null; called: boolean; marked: boolean; }

@Component({
  selector: 'app-game',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="gp">

      <!-- ── HEADER ──────────────────────────────────────────────────────── -->
      <header class="gh">
        <div class="gh-left">
          <button class="btn-back" routerLink="/lobby">← Lobby</button>
          <div class="gh-contest">
            <span class="gh-name">{{ contest()?.name }}</span>
            <span class="gh-pool">Prize Pool · ₹{{ contest()?.prizePool | number }}</span>
          </div>
        </div>

        <div class="gh-call-box" [class.pop]="justCalled()">
          <div class="gh-call-lbl">LAST CALLED</div>
          <div class="gh-call-num">{{ latestNumber() ?? '—' }}</div>
          @if (latestNumber()) {
            <div class="gh-call-nick">{{ nickname(latestNumber()!) }}</div>
          }
        </div>

        <div class="gh-right">
          <div class="gh-timer" [class.urgent]="nextCallIn() <= 5 && gamePhase() === 'IN_PROGRESS'">
            <div class="gh-timer-lbl">Next call in</div>
            <div class="gh-timer-val">{{ nextCallIn() }}s</div>
          </div>
          <div class="gh-earn">
            <div class="gh-earn-lbl">My Earnings</div>
            <div class="gh-earn-val">₹{{ myEarnings() }}</div>
          </div>
          <button class="btn-voice" (click)="toggleVoice()">{{ voiceOn() ? '🔊' : '🔇' }}</button>
          <div class="ws-indicator" [class.on]="wsConnected()" title="Connection status"></div>
        </div>
      </header>

      <!-- ── COUNTDOWN OVERLAY ────────────────────────────────────────────── -->
      @if (gamePhase() === 'COUNTDOWN') {
        <div class="overlay">
          <div class="cdo-box">
            <div class="cdo-num">{{ countdown() }}</div>
            <div class="cdo-msg">Game starting…</div>
            <div class="cdo-sub">Get ready to mark your card!</div>
          </div>
        </div>
      }

      <!-- ── GAME OVER OVERLAY ────────────────────────────────────────────── -->
      @if (gamePhase() === 'COMPLETED') {
        <div class="overlay">
          <div class="go-box">
            <div class="go-icon">{{ myEarnings() > 0 ? '🏆' : '😢' }}</div>
            <h2 class="go-title">{{ myEarnings() > 0 ? 'You Won!' : 'Better luck next time' }}</h2>
            @if (myEarnings() > 0) {
              <div class="go-amt">₹{{ myEarnings() }}</div>
              <div class="go-prizes">{{ wonPrizeLabels().join(' · ') }}</div>
            } @else {
              <p class="go-sub">The numbers weren't in your favour this time. Try another contest!</p>
            }
            <button class="btn-go-lobby" routerLink="/lobby">Back to Lobby</button>
          </div>
        </div>
      }

      <!-- ── TOAST ──────────────────────────────────────────────────────────── -->
      @if (toast()) {
        <div class="toast" [class.toast-win]="toast()!.win">{{ toast()!.msg }}</div>
      }

      <!-- ── HOST CONTROLS ────────────────────────────────────────────────── -->
      @if (isPrivateContest() && isHost() && gamePhase() === 'WAITING') {
        <div class="host-bar">
          <div class="host-bar-left">
            <span class="host-icon">🎙️</span>
            <span>You're hosting this contest — <strong>{{ contest()?.currentPlayers }}/{{ contest()?.maxPlayers }}</strong> players joined</span>
          </div>
          <button class="btn-start-now" (click)="startNow()"
            [disabled]="startingNow() || (contest()?.currentPlayers ?? 0) < 2">
            {{ startingNow() ? 'Starting…' : '🚀 Start Game Now' }}
          </button>
        </div>
        @if (startError()) {
          <div class="host-bar-error">⚠ {{ startError() }}</div>
        }
      }

      <!-- ── MAIN LAYOUT ────────────────────────────────────────────────────── -->
      <div class="g-layout">

        <!-- ═══════════════ LEFT COLUMN ═══════════════ -->
        <div class="g-left">

          <!-- NUMBER BOARD -->
          <div class="panel">
            <div class="panel-head">
              <span class="panel-title">🔢 Number Board</span>
              <span class="panel-sub">{{ calledNumbers().length }}/90 called · Red = called</span>
            </div>
            <div class="master-grid">
              @for (n of allNumbers; track n) {
                <div class="mg-cell"
                  [class.mg-called]="isNumberCalled(n)"
                  [class.mg-latest]="n === latestNumber()">
                  <span class="mg-num">{{ n }}</span>
                  @if (isNumberCalled(n)) { <span class="mg-strike"></span> }
                </div>
              }
            </div>
          </div>

          <!-- PLAYER CARD -->
          <div class="panel">
            <div class="panel-head">
              <span class="panel-title">🎴 Your Card</span>
              <div class="card-controls">
                <span class="marked-count">Marked: <strong>{{ markedCount() }}/15</strong></span>
                <label class="toggle">
                  <input type="checkbox" [checked]="autoMark()"
                    (change)="autoMark.set(!autoMark())" />
                  <span class="toggle-slider"></span>
                  Auto-Mark
                </label>
              </div>
            </div>

            @if (card().length) {
              <div class="card-cols">
                @for (lbl of colLabels; track lbl) {
                  <div class="card-col-lbl">{{ lbl }}</div>
                }
              </div>
              <div class="housie-card">
                @for (row of card(); track row; let ri = $index) {
                  <div class="hc-row" [class.hc-row-done]="isRowComplete(ri)">
                    @for (cell of row; track cell) {
                      <div class="hc-cell"
                        [class.hc-blank]="!cell.value"
                        [class.hc-called]="cell.called && !cell.marked"
                        [class.hc-marked]="cell.marked"
                        (click)="toggleMark(cell)">
                        @if (cell.value) {
                          <span class="hc-num">{{ cell.value }}</span>
                          @if (cell.marked) { <span class="hc-tick">✓</span> }
                        }
                      </div>
                    }
                  </div>
                }
              </div>
              <div class="card-legend">
                <span><span class="leg called-leg"></span> Called (tap to mark)</span>
                <span><span class="leg marked-leg"></span> Marked ✓</span>
                <span><span class="leg blank-leg"></span> Blank</span>
              </div>
            } @else {
              <div class="no-card">👁 Watching only — join next round to play!</div>
            }
          </div>

          <!-- RECENT CALLS -->
          <div class="panel">
            <div class="panel-head"><span class="panel-title">📢 Recent Calls</span></div>
            <div class="recent-row">
              @for (n of recentCalled(); track n; let i = $index) {
                <div class="rc-ball" [class.rc-latest]="i === 0" [class.rc-mine]="isOnMyCard(n)">
                  {{ n }}
                  @if (isOnMyCard(n)) { <span class="rc-star">★</span> }
                </div>
              }
            </div>
            <div class="recent-hint">★ = on your card</div>
          </div>

        </div>

        <!-- ═══════════════ RIGHT COLUMN ═══════════════ -->
        <div class="g-right">

          <!-- ── PRIZE BOARD — wrapped for side-card positioning ── -->
          <div class="prize-wrapper">

            <div class="panel prize-panel">
              <div class="panel-head">
                <span class="panel-title">🏆 Prize Board</span>
                @if (myEarnings() > 0) {
                  <span class="my-earn-chip">You: ₹{{ myEarnings() }}</span>
                }
              </div>

              @for (entry of prizeEntries(); track entry[0]) {
                <div class="prize-row"
                  [class.pr-won]="hasWinners(entry[0])"
                  [class.pr-mine]="isMyPrize(entry[0])">
                  <div class="pr-icon">{{ prizeIcon(entry[0]) }}</div>
                  <div class="pr-info">
                    <div class="pr-name">{{ entry[1].label }}</div>
                    <div class="pr-desc">{{ entry[1].desc }}</div>
                  </div>
                  <div class="pr-right">
                    <div class="pr-amt" [class.pr-amt-won]="hasWinners(entry[0])">
                      ₹{{ entry[1].amount }}
                    </div>
                    <!-- ✅ Red dot — click opens side card -->
                    @if (hasWinners(entry[0])) {
                      <button class="winner-dot"
                        [class.dot-open]="expandedPrize() === entry[0]"
                        (click)="expandedPrize.set(expandedPrize() === entry[0] ? null : entry[0])"
                        title="See winners">
                        {{ getWinners(entry[0]).length }}
                      </button>
                    }
                  </div>
                </div>
                <!-- ✅ NO inline winner panel here anymore -->
              }

              @if (myEarnings() > 0) {
                <div class="my-winnings">
                  <div class="mw-label">Your Winnings</div>
                  <div class="mw-amt">₹{{ myEarnings() }}</div>
                </div>
              }
            </div>

            <!-- ✅ WINNER SIDE CARD — floats to the right of prize panel -->
            @if (expandedPrize() && hasWinners(expandedPrize()!)) {
              <div class="winner-side-card">
                <div class="wsc-header">
                  <div class="wsc-title">
                    <span class="wsc-icon">{{ prizeIcon(expandedPrize()!) }}</span>
                    <span>{{ getPrizeLabel(expandedPrize()!) }}</span>
                  </div>
                  <button class="wsc-close" (click)="expandedPrize.set(null)" title="Close">✕</button>
                </div>

                <div class="wsc-list">
                  @for (w of getWinners(expandedPrize()!); track w.name; let i = $index) {
                    <div class="wsc-row" [class.wsc-row-me]="w.name === authService.user()?.fullName">
                      <span class="wsc-rank">#{{ i + 1 }}</span>
                      <span class="wsc-name">
                        {{ w.name }}
                        @if (w.name === authService.user()?.fullName) {
                          <span class="wsc-you-tag">You</span>
                        }
                      </span>
                      <span class="wsc-amt">₹{{ w.amount }}</span>
                    </div>
                  }
                </div>

                @if (getWinners(expandedPrize()!).length > 1) {
                  <div class="wsc-note">Prize split equally among all winners</div>
                }
              </div>
            }

          </div>
          <!-- end prize-wrapper -->

          <!-- GAME INFO -->
          <div class="panel">
            <div class="panel-head"><span class="panel-title">📊 Game Info</span></div>
            <div class="info-grid">
              <div class="ig-item">
                <div class="ig-lbl">Numbers Called</div>
                <div class="ig-val">{{ calledNumbers().length }}/90</div>
                <div class="ig-bar">
                  <div class="ig-fill" [style.width.%]="calledNumbers().length / 90 * 100"></div>
                </div>
              </div>
              <div class="ig-item">
                <div class="ig-lbl">Players</div>
                <div class="ig-val">{{ contest()?.currentPlayers }}/{{ contest()?.maxPlayers }}</div>
                <div class="ig-bar">
                  <div class="ig-fill green"
                    [style.width.%]="(contest()?.currentPlayers ?? 0) / (contest()?.maxPlayers ?? 1) * 100">
                  </div>
                </div>
              </div>
              <div class="ig-item">
                <div class="ig-lbl">My Marked</div>
                <div class="ig-val">{{ markedCount() }}/15</div>
                <div class="ig-bar">
                  <div class="ig-fill purple" [style.width.%]="markedCount() / 15 * 100"></div>
                </div>
              </div>
              <div class="ig-item">
                <div class="ig-lbl">Prizes Claimed</div>
                <div class="ig-val">{{ prizesClaimed() }}/{{ totalPrizes() }}</div>
              </div>
            </div>
          </div>

          <!-- HOW TO WIN -->
          <div class="panel rules-panel">
            <div class="panel-head"><span class="panel-title">📋 How to Win</span></div>
            <div class="rules-list">
              <div class="rule-item">
                <span class="rule-icon">⚡</span>
                <span><strong>Early Five</strong> — First 5 numbers on your card · ₹15</span>
              </div>
              <div class="rule-item">
                <span class="rule-icon">1️⃣</span>
                <span><strong>1st / 2nd / 3rd Line</strong> — Complete any row · ₹10 each</span>
              </div>
              <div class="rule-item">
                <span class="rule-icon">🔝</span>
                <span><strong>Top Half</strong> — Both top rows done · ₹25</span>
              </div>
              <div class="rule-item">
                <span class="rule-icon">🏆</span>
                <span><strong>Full House</strong> — All 15 numbers marked · ₹100</span>
              </div>
            </div>
            <div class="rules-note">
              ℹ️ Prizes are credited instantly to your wallet. One winner per prize.
              Auto-Mark fills your card automatically as numbers are called.
            </div>
          </div>

        </div>
      </div>
    </div>
  `,
  styleUrls: ['./game.component.scss']
})
export class GameComponent implements OnInit, OnDestroy {

  contest       = signal<Contest | null>(null);
  gamePhase     = signal<'WAITING'|'COUNTDOWN'|'IN_PROGRESS'|'COMPLETED'>('WAITING');
  calledNumbers = signal<number[]>([]);
  latestNumber  = signal<number | null>(null);
  claimedPrizes = signal<Record<string, string>>({});
  card          = signal<CardCell[][]>([]);
  autoMark      = signal(true);
  countdown     = signal(10);
  nextCallIn    = signal(20);
  myEarnings    = signal(0);
  wonPrizes     = signal<PrizeType[]>([]);
  toast         = signal<{msg:string;win:boolean}|null>(null);
  voiceOn       = signal(true);
  wsConnected   = signal(false);
  justCalled    = signal(false);

  isPrivateContest = signal(false);
  isHost            = signal(false);
  startingNow       = signal(false);
  startError        = signal('');

  colLabels  = ['1-9','10-19','20-29','30-39','40-49','50-59','60-69','70-79','80-90'];
  allNumbers = Array.from({length:90},(_,i)=>i+1);

  prizeEntries = signal<[string, {label:string;desc:string;amount:number}][]>([]);

  readonly NICK: Record<number,string> = {
    1:"Kelly's Eye",7:"Lucky Seven",8:"One Fat Lady",9:"Doctor's Orders",
    10:"(Gordon's) Den",11:"Legs Eleven",13:"Unlucky for Some",
    21:"Key of the Door",22:"Two Little Ducks",33:"All the Threes",
    44:"Droopy Drawers",55:"Snakes Alive",66:"Clickety Click",
    77:"Sunset Strip",88:"Two Fat Ladies",90:"Top of the Shop",
  };
  nickname = (n: number) => this.NICK[n] ?? '';

  recentCalled   = computed(() => [...this.calledNumbers()].reverse().slice(0, 18));
  markedCount    = computed(() => this.card().flat().filter(c=>c.marked).length);
  wonPrizeLabels = computed(() => this.wonPrizes().map(p=>PRIZE_DEFINITIONS[p]?.label ?? p));
  prizesClaimed  = computed(() => Object.keys(this.claimedPrizes()).length);
  totalPrizes    = computed(() => this.prizeEntries().length);

  winnersMap    = signal<Record<string, { name: string; amount: number }[]>>({});
  expandedPrize = signal<string | null>(null);

  isNumberCalled = (n: number) => this.calledNumbers().includes(n);
  isOnMyCard     = (n: number) => this.card().flat().some(c => c.value === n);
  isMyPrize      = (key: string) => this.claimedPrizes()[key] === this.authService.user()?.fullName;
  isRowComplete  = (ri: number) => this.card()[ri]?.filter(c=>c.value).every(c=>c.marked) ?? false;

  prizeIcon(key: string) {
    return {EARLY_FIVE:'⚡',FIRST_LINE:'1️⃣',SECOND_LINE:'2️⃣',
            THIRD_LINE:'3️⃣',TOP_HALF:'🔝',FULL_HOUSE:'🏆'}[key] ?? '🎯';
  }

  /** ✅ NEW — looks up the display label for the currently expanded prize */
  getPrizeLabel(prizeKey: string): string {
    const entry = this.prizeEntries().find(e => e[0] === prizeKey);
    return entry?.[1]?.label ?? prizeKey;
  }

  hasWinners(prizeType: string): boolean {
    const list = this.winnersMap()[prizeType];
    return list !== undefined && list !== null && list.length > 0;
  }

  getWinners(prizeType: string): { name: string; amount: number }[] {
    return this.winnersMap()[prizeType] ?? [];
  }

  private subs       = new Subscription();
  private timerRef?: any;
  private toastRef?: any;
  private contestId!: number;

  constructor(
    private route:                 ActivatedRoute,
    private router:                Router,
    readonly authService:          AuthService,   // ✅ readonly so template can access it
    private contestService:        ContestService,
    private privateContestService: PrivateContestService,
    private wsService:             WebSocketService,
    private voiceService:          VoiceService,
  ) {}

  ngOnInit() {
    this.contestId = Number(this.route.snapshot.paramMap.get('contestId'));
    const cardData = history.state?.cardData as string | undefined;
    if (cardData) this.initCard(cardData);

    this.prizeEntries.set(
      Object.entries(PRIZE_DEFINITIONS) as [string, {label:string;desc:string;amount:number}][]
    );

    this.privateContestService.getById(this.contestId).subscribe({
      next: (pc) => {
        this.isPrivateContest.set(true);
        this.isHost.set(pc.isCreator);

        this.prizeEntries.set(
          pc.prizeRules.map(r => [
            r.prizeType,
            { label: r.displayName, desc: r.description, amount: r.amount }
          ] as [string, { label: string; desc: string; amount: number }])
        );

        this.contest.set({
          id: pc.id, name: pc.name, prizePool: pc.prizePool,
          entryFee: pc.entryFee, maxPlayers: pc.maxPlayers,
          currentPlayers: pc.currentPlayers, status: pc.status,
          badge: '', colorHex: '#1DB971', createdAt: pc.createdAt,
          startedAt: null, spotsLeft: pc.spotsLeft,
          fillPercentage: (pc.currentPlayers / pc.maxPlayers) * 100,
        } as Contest);

        if (pc.status === 'IN_PROGRESS') this.gamePhase.set('IN_PROGRESS');
        if (pc.status === 'COMPLETED')   this.gamePhase.set('COMPLETED');
        if (!cardData && pc.cardData) this.initCard(pc.cardData);

        this.connectWebSocket(true);
      },
      error: () => {
        this.isPrivateContest.set(false);
        this.loadPublicContest(cardData);
      },
    });
  }

  private loadPublicContest(cardData: string | undefined) {
    this.contestService.getContest(this.contestId).subscribe(c => {
      this.contest.set(c);
      if (c.status === 'IN_PROGRESS') this.gamePhase.set('IN_PROGRESS');
      if (c.status === 'COMPLETED')   this.gamePhase.set('COMPLETED');
    });
    this.contestService.getCalledNumbers(this.contestId).subscribe(nums => {
      this.calledNumbers.set(nums);
      if (nums.length) { this.latestNumber.set(nums[nums.length-1]); this.syncCard(); }
    });
    this.connectWebSocket(false);
  }

  private connectWebSocket(isPrivate: boolean) {
    const token = this.authService.getToken() ?? '';
    this.wsService.connect(this.contestId, token, isPrivate);
    this.subs.add(this.wsService.connectionStatus$.subscribe(s => this.wsConnected.set(s==='CONNECTED')));
    this.subs.add(this.wsService.getMessages().subscribe(m => this.onMessage(m)));
  }

  startNow() {
    this.startError.set('');
    this.startingNow.set(true);
    this.privateContestService.startNow(this.contestId).subscribe({
      next: () => { this.startingNow.set(false); },
      error: e => { this.startError.set(e?.error?.message ?? 'Could not start game'); this.startingNow.set(false); },
    });
  }

  ngOnDestroy() { this.subs.unsubscribe(); this.wsService.disconnect(); clearInterval(this.timerRef); }

  private onMessage(msg: GameMessage) {
    if (msg.claimedPrizes) this.claimedPrizes.set(msg.claimedPrizes);

    switch (msg.type) {
      case 'COUNTDOWN':
        this.gamePhase.set('COUNTDOWN');
        this.countdown.set(msg.countdownSeconds ?? 10);
        if (this.voiceOn()) this.voiceService.announceCountdown(msg.countdownSeconds ?? 0);
        if ((msg.countdownSeconds ?? 0) === 0) {
          setTimeout(() => { if (this.gamePhase() === 'COUNTDOWN') this.gamePhase.set('IN_PROGRESS'); }, 1200);
          if (this.voiceOn()) this.voiceService.announceGameStart();
        }
        break;

      case 'GAME_STATUS':
        if (msg.gameStatus === 'IN_PROGRESS') this.gamePhase.set('IN_PROGRESS');
        if (msg.gameStatus === 'COMPLETED') {
          this.gamePhase.set('COMPLETED');
          if (this.voiceOn()) this.voiceService.announceGameOver();
        }
        if (msg.currentPlayers !== undefined)
          this.contest.update(c => c ? {...c, currentPlayers: msg.currentPlayers!} : c);
        break;

      case 'NUMBER_CALLED':
        const num = msg.calledNumber!;
        this.calledNumbers.set(msg.allCalledNumbers ?? [...this.calledNumbers(), num]);
        this.latestNumber.set(num);
        this.nextCallIn.set(msg.nextCallInSeconds ?? 20);
        this.justCalled.set(true);
        setTimeout(() => this.justCalled.set(false), 600);
        if (this.voiceOn()) { this.voiceService.announceNumber(num); this.voiceService.playBeep(440, 100); }
        this.syncCard();
        this.startTimer(msg.nextCallInSeconds ?? 20);
        break;

      case 'PRIZE_WON':
        const myId     = this.authService.user()?.id;
        const isMe     = msg.winnerId === myId;
        const lbl      = msg.prizeDisplayName ?? '';
        const prizeKey = (msg.prizeType as string) ?? '';

        this.winnersMap.update(map => {
          const existing = map[prizeKey] ?? [];
          if (existing.some(w => w.name === (msg.winnerName ?? ''))) return map;
          return { ...map, [prizeKey]: [...existing, { name: msg.winnerName ?? '', amount: msg.prizeAmount ?? 0 }] };
        });

        this.claimedPrizes.update(map => {
          if (map[prizeKey]) return map;
          return { ...map, [prizeKey]: msg.winnerName ?? '' };
        });

        if (isMe) {
          this.myEarnings.update(e => e + (msg.prizeAmount ?? 0));
          this.wonPrizes.update(p => [...p, msg.prizeType!]);
          this.authService.updateWallet((this.authService.user()?.walletBalance ?? 0) + (msg.prizeAmount ?? 0));
          this.showToast(`🎉 ${lbl} — You won ₹${msg.prizeAmount}!`, true);
          if (this.voiceOn()) { this.voiceService.playWinSound(); this.voiceService.announcePrizeWon(lbl, 'You'); }
        } else {
          this.showToast(`🏆 ${lbl} claimed by ${msg.winnerName}`, false);
          if (this.voiceOn()) this.voiceService.announcePrizeWon(lbl, msg.winnerName ?? '');
        }
        break;
    }
  }

  private initCard(cardData: string) {
    const vals = cardData.split('|').map(Number);
    const rows: CardCell[][] = [];
    for (let r=0;r<3;r++) {
      const row: CardCell[] = [];
      for (let c=0;c<9;c++) { const v=vals[r*9+c]; row.push({value:v||null,called:false,marked:false}); }
      rows.push(row);
    }
    this.card.set(rows);
  }

  private syncCard() {
    const called = new Set(this.calledNumbers());
    this.card.update(rows => rows.map(row => row.map(cell => {
      if (!cell.value) return cell;
      const isCalled = called.has(cell.value);
      return { ...cell, called: isCalled, marked: cell.marked || (this.autoMark() && isCalled) };
    })));
  }

  toggleMark(cell: CardCell) {
    if (!cell.value || !cell.called) return;
    this.card.update(rows => rows.map(row => row.map(c =>
      c.value === cell.value ? {...c, marked: !c.marked} : c)));
  }

  private startTimer(seconds: number) {
    clearInterval(this.timerRef);
    this.nextCallIn.set(seconds);
    this.timerRef = setInterval(() => this.nextCallIn.update(n => n > 0 ? n-1 : 0), 1000);
  }

  private showToast(msg: string, win: boolean) {
    clearTimeout(this.toastRef);
    this.toast.set({msg, win});
    this.toastRef = setTimeout(() => this.toast.set(null), 4000);
  }

  toggleVoice() {
    const next = !this.voiceOn();
    this.voiceOn.set(next);
    this.voiceService.setEnabled(next);
  }
}
