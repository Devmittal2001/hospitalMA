import { Component, OnInit, signal } from '@angular/core';
import { CommonModule }   from '@angular/common';
import { FormsModule }    from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { HttpClient }     from '@angular/common/http';
import { AuthService }    from '../../core/services/auth.service';
import { environment }    from '../../../environments/environment';

@Component({
  selector: 'app-join-contest',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page">
      <nav class="nav">
        <div class="brand">🎱 BingoLive</div>
        <button class="btn-back" routerLink="/lobby">← Lobby</button>
      </nav>

      <div class="body">
        <div class="join-card">

          @if (!preview()) {
            <!-- Step 1: Enter invite code -->
            <div class="jc-icon">🔗</div>
            <h2>Join a Contest</h2>
            <p class="jc-sub">Enter the invite code shared by the host</p>

            <div class="field">
              <label>Invite Code</label>
              <input [(ngModel)]="inviteCode" placeholder="BINGO-XXXXXX"
                (input)="inviteCode = inviteCode.toUpperCase().trim()"
                maxlength="12" class="code-input" />
            </div>

            @if (lookupError()) {
              <div class="err-box">⚠ {{ lookupError() }}</div>
            }

            <button class="btn-primary" (click)="lookup()" [disabled]="lookupLoading()">
              {{ lookupLoading() ? 'Looking up…' : 'Find Contest →' }}
            </button>

          } @else {
            <!-- Step 2: Preview + enter passcode -->
            <div class="preview">
              <div class="prev-tag">🔐 Private Contest</div>
              <div class="prev-name">{{ preview()!.name }}</div>
              @if (preview()!.description) {
                <p class="prev-desc">{{ preview()!.description }}</p>
              }

              <div class="prev-stats">
                <div class="ps"><div class="ps-l">Prize Pool</div><div class="ps-v green">₹{{ preview()!.prizePool | number }}</div></div>
                <div class="ps"><div class="ps-l">Entry Fee</div><div class="ps-v">₹{{ preview()!.entryFee }}</div></div>
                <div class="ps"><div class="ps-l">Players</div><div class="ps-v" [class.urgent]="preview()!.spotsLeft <= 2">{{ preview()!.currentPlayers }}/{{ preview()!.maxPlayers }}</div></div>
                <div class="ps"><div class="ps-l">Call Speed</div><div class="ps-v">{{ preview()!.callIntervalSeconds }}s</div></div>
              </div>

              <!-- Prize rules -->
              <div class="prev-prizes">
                <div class="pp-title">🏆 Prize Rules</div>
                @for (r of preview()!.prizeRules; track r.prizeType) {
                  <div class="pp-row">
                    <span>{{ r.displayName }}</span>
                    <span class="pp-amt">₹{{ r.amount }}</span>
                  </div>
                }
              </div>

              <!-- Hosted by -->
              <div class="hosted-by">Hosted by <strong>{{ preview()!.creatorName }}</strong></div>

              @if (preview()!.hasJoined) {
                <div class="already-joined">✅ You're already in this contest!</div>
                <button class="btn-primary" [routerLink]="['/game', preview()!.id]">Go to Game Room →</button>
              } @else if (preview()!.status !== 'WAITING' && preview()!.status !== 'STARTING') {
                <div class="err-box">This contest is {{ preview()!.status | lowercase }} and no longer accepting players.</div>
              } @else {
                <!-- Passcode entry -->
                <div class="field">
                  <label>Passcode <span class="hint">(ask the host)</span></label>
                  <div class="passcode-dots">
                    @for (i of [0,1,2,3,4,5,6,7]; track i) {
                      <div class="pdot" [class.filled]="passcode.length > i"></div>
                    }
                  </div>
                  <input type="password" [(ngModel)]="passcode"
                    placeholder="Enter passcode" maxlength="8"
                    pattern="[0-9]*" inputmode="numeric"
                    class="pass-input" />
                </div>

                <!-- Wallet check -->
                <div class="wallet-check" [class.ok]="canAfford()" [class.low]="!canAfford()">
                  @if (canAfford()) {
                    ✅ Wallet balance ₹{{ userBalance() }} — sufficient
                  } @else {
                    ⚠ Need ₹{{ (preview()!.entryFee - userBalance()) | number:'1.0-0' }} more
                    <button class="btn-topup" routerLink="/wallet">Add Funds</button>
                  }
                </div>

                @if (joinError()) {
                  <div class="err-box">⚠ {{ joinError() }}</div>
                }

                <button class="btn-primary" (click)="join()"
                  [disabled]="joinLoading() || !canAfford()">
                  {{ joinLoading() ? 'Joining…' : 'Join for ₹' + preview()!.entryFee + ' →' }}
                </button>

                <button class="btn-change" (click)="reset()">← Different code</button>
              }
            </div>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page { min-height:100vh; background:var(--bg); font-family:'Inter',sans-serif; }
    .nav { background:var(--white); border-bottom:2px solid var(--green-500); padding:0 32px; height:60px; display:flex; align-items:center; justify-content:space-between; box-shadow:var(--shadow-sm); }
    .brand { font-family:'Nunito',sans-serif; font-size:20px; font-weight:900; color:var(--green-600); }
    .btn-back { padding:7px 16px; border-radius:var(--radius-sm); border:1.5px solid var(--border); background:var(--white); font-size:13px; color:var(--text-2); font-weight:600; cursor:pointer; }
    .body { display:flex; justify-content:center; align-items:flex-start; padding:48px 20px; }
    .join-card { background:var(--white); border:1.5px solid var(--border); border-radius:var(--radius-xl); padding:44px 40px; max-width:480px; width:100%; box-shadow:var(--shadow-lg); text-align:center; }
    .jc-icon { font-size:48px; margin-bottom:12px; }
    h2 { font-family:'Nunito',sans-serif; font-size:26px; font-weight:900; color:var(--text-1); margin-bottom:6px; }
    .jc-sub { color:var(--text-3); font-size:14px; margin-bottom:28px; }
    .field { text-align:left; margin-bottom:16px; label { display:block; font-size:13px; font-weight:600; color:var(--text-2); margin-bottom:6px; .hint { font-weight:400; color:var(--text-4); } } }
    input { width:100%; padding:12px 16px; border:1.5px solid var(--border); border-radius:var(--radius-md); font-size:15px; color:var(--text-1); background:var(--surface); outline:none; box-sizing:border-box; &:focus { border-color:var(--green-500); } }
    .code-input { font-family:'Nunito',sans-serif; font-size:22px; font-weight:800; letter-spacing:4px; text-align:center; text-transform:uppercase; }
    .err-box { background:var(--red-light); color:var(--red); border:1px solid #FECACA; border-radius:var(--radius-md); padding:12px; font-size:13px; font-weight:600; margin-bottom:14px; text-align:left; }
    .btn-primary { width:100%; padding:14px; border:none; border-radius:var(--radius-md); background:var(--green-500); color:#fff; font-size:16px; font-weight:800; font-family:'Nunito',sans-serif; cursor:pointer; &:hover:not(:disabled) { background:var(--green-600); } &:disabled { opacity:.5; cursor:not-allowed; } }
    .btn-change { width:100%; margin-top:10px; padding:10px; border:1.5px solid var(--border); border-radius:var(--radius-md); background:var(--white); font-size:13px; color:var(--text-3); cursor:pointer; }

    // Preview styles
    .preview { text-align:left; }
    .prev-tag { display:inline-block; background:var(--green-50); border:1px solid var(--green-400); color:var(--green-700); border-radius:20px; padding:3px 12px; font-size:11px; font-weight:800; margin-bottom:10px; }
    .prev-name { font-family:'Nunito',sans-serif; font-size:22px; font-weight:900; color:var(--text-1); margin-bottom:6px; }
    .prev-desc { font-size:13px; color:var(--text-3); margin-bottom:16px; }
    .prev-stats { display:grid; grid-template-columns:1fr 1fr; gap:8px; background:var(--bg); border-radius:var(--radius-md); padding:14px; margin-bottom:14px; }
    .ps { text-align:center; }
    .ps-l { font-size:10px; color:var(--text-3); text-transform:uppercase; letter-spacing:.4px; }
    .ps-v { font-family:'Nunito',sans-serif; font-size:18px; font-weight:800; color:var(--text-1); &.green { color:var(--green-600); } &.urgent { color:var(--red); } }
    .prev-prizes { margin-bottom:14px; }
    .pp-title { font-size:13px; font-weight:700; color:var(--text-2); margin-bottom:8px; }
    .pp-row { display:flex; justify-content:space-between; font-size:13px; color:var(--text-1); padding:4px 0; border-bottom:1px solid var(--border); }
    .pp-amt { font-weight:700; color:var(--green-600); }
    .hosted-by { font-size:12px; color:var(--text-3); margin-bottom:20px; strong { color:var(--text-1); } }
    .already-joined { background:var(--green-50); border:1.5px solid var(--green-400); border-radius:var(--radius-md); padding:12px; font-size:14px; font-weight:700; color:var(--green-700); margin-bottom:14px; text-align:center; }

    // Passcode dots
    .passcode-dots { display:flex; gap:8px; justify-content:center; margin-bottom:10px; }
    .pdot { width:14px; height:14px; border-radius:50%; border:2px solid var(--border); background:transparent; transition:background .15s, border-color .15s; &.filled { background:var(--green-500); border-color:var(--green-600); } }
    .pass-input { text-align:center; letter-spacing:8px; font-size:20px; }

    // Wallet check
    .wallet-check { border-radius:var(--radius-md); padding:10px 14px; font-size:13px; font-weight:600; margin-bottom:14px; display:flex; align-items:center; justify-content:space-between; gap:8px; &.ok { background:var(--green-50); border:1.5px solid var(--green-100); color:var(--green-700); } &.low { background:var(--red-light); border:1.5px solid #FECACA; color:var(--red); } }
    .btn-topup { background:var(--red); color:#fff; border:none; border-radius:var(--radius-sm); padding:5px 12px; font-size:12px; font-weight:700; cursor:pointer; }
  `]
})
export class JoinContestComponent implements OnInit {
  inviteCode = '';
  passcode   = '';
  preview    = signal<any>(null);
  lookupLoading = signal(false);
  lookupError   = signal('');
  joinLoading   = signal(false);
  joinError     = signal('');

  userBalance = signal(0);

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private auth: AuthService
  ) {}

  ngOnInit() {
    this.userBalance.set(this.auth.user()?.walletBalance ?? 0);
    // Support deep link: /join/BINGO-XXXXX
    const code = this.route.snapshot.paramMap.get('inviteCode');
    if (code) { this.inviteCode = code.toUpperCase(); this.lookup(); }
  }

  canAfford() { return this.preview() ? this.userBalance() >= this.preview()!.entryFee : false; }

  lookup() {
    this.lookupError.set('');
    if (!this.inviteCode.match(/^BINGO-[A-Z0-9]{6}$/)) {
      return this.lookupError.set('Invalid format. Should be BINGO-XXXXXX');
    }
    this.lookupLoading.set(true);
    this.http.get<any>(`${environment.apiUrl}/private-contests/lookup/${this.inviteCode}`).subscribe({
      next: data => { this.preview.set(data); this.lookupLoading.set(false); },
      error: e   => { this.lookupError.set(e?.error?.message ?? 'Contest not found'); this.lookupLoading.set(false); }
    });
  }

  join() {
    this.joinError.set('');
    if (!this.passcode) return this.joinError.set('Enter the passcode.');
    this.joinLoading.set(true);
    this.http.post<any>(`${environment.apiUrl}/private-contests/join`, {
      inviteCode: this.inviteCode, passcode: this.passcode
    }).subscribe({
      next: res => {
        this.auth.updateWallet(this.userBalance() - res.entryFee);
        this.router.navigate(['/game', res.id], { state: { cardData: res.cardData } });
      },
      error: e => { this.joinError.set(e?.error?.message ?? 'Could not join'); this.joinLoading.set(false); }
    });
  }

  reset() { this.preview.set(null); this.passcode = ''; this.joinError.set(''); }
}
