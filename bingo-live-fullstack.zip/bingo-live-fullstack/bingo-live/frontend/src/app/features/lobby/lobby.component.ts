import { Component, OnInit, OnDestroy, signal, computed } from '@angular/core';
import { CommonModule }    from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { HttpClient }      from '@angular/common/http';
import { interval, Subscription } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { AuthService }    from '../../core/services/auth.service';
import { ContestService } from '../../core/services/contest.service';
import { Contest, PRIZE_DEFINITIONS } from '../../shared/models';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-lobby',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="lobby-page">

      <!-- ── TOP NAV ─────────────────────────────────────────────────── -->
      <nav class="nav">
        <div class="nav-brand">
          <div class="brand-icon">🎱</div>
          <span class="brand-name">BingoLive</span>
          <span class="brand-tag">BETA</span>
        </div>
        <div class="nav-right">
          <div class="wallet-box">
            <span class="wallet-icon">💰</span>
            <div>
              <div class="wallet-lbl">My Wallet</div>
              <div class="wallet-val">₹{{ user()?.walletBalance | number:'1.0-0' }}</div>
            </div>
            <button class="btn-add-funds" routerLink="/wallet">+ Add Funds</button>
          </div>
          <div class="user-chip">
            <div class="avatar">{{ initial() }}</div>
            <span class="uname">{{ firstName() }}</span>
          </div>
          <button class="btn-logout" (click)="logout()">Sign out</button>
        </div>
      </nav>

      <div class="lobby-body">

        <!-- ── HERO ──────────────────────────────────────────────────── -->
        <div class="hero">
          <div class="hero-left">
            <div class="live-chip"><span class="live-dot"></span> LIVE NOW</div>
            <h1 class="hero-title">Play Bingo.<br>Win Real Money.</h1>
            <p class="hero-sub">Join a contest, mark your card, claim prizes in real time.</p>
          </div>
          <div class="hero-stats">
            <div class="hstat">
              <div class="hstat-val">{{ contests().length }}</div>
              <div class="hstat-lbl">Live Contests</div>
            </div>
            <div class="hstat-div"></div>
            <div class="hstat">
              <div class="hstat-val green">₹62,900</div>
              <div class="hstat-lbl">Total Prize Pool</div>
            </div>
            <div class="hstat-div"></div>
            <div class="hstat">
              <div class="hstat-val">20s</div>
              <div class="hstat-lbl">Per Number</div>
            </div>
          </div>
        </div>

        <!-- ── HOST YOUR OWN CONTEST ─────────────────────────────────── -->
        <div class="host-banner">
          <div class="hb-left">
            <div class="hb-icon">🏟️</div>
            <div>
              <div class="hb-title">Host Your Own Contest</div>
              <div class="hb-sub">Set your own entry fee, prize rules, and invite friends with a passcode-protected link</div>
            </div>
          </div>
          <div class="hb-actions">
            <button class="btn-host" routerLink="/create-contest">+ Create Contest</button>
            <button class="btn-join-code" routerLink="/join">🔑 Join via Code</button>
          </div>
        </div>

        <!-- ── MY CONTESTS (if any) ─────────────────────────────────── -->
        @if (myContests().length > 0) {
          <section class="section">
            <div class="section-head">
              <h2 class="section-title">👤 My Hosted & Joined Contests</h2>
            </div>
            <div class="my-contests-row">
              @for (mc of myContests(); track mc.id) {
                <div class="mc-card" [routerLink]="['/game', mc.id]">
                  <div class="mc-top">
                    <span class="mc-name">{{ mc.name }}</span>
                    @if (mc.isCreator) { <span class="mc-host-tag">HOST</span> }
                  </div>
                  <div class="mc-stats">
                    <span>₹{{ mc.prizePool | number }} pool</span>
                    <span>{{ mc.currentPlayers }}/{{ mc.maxPlayers }}</span>
                    <span class="mc-status" [class]="'mcs-' + mc.status.toLowerCase()">{{ mc.status }}</span>
                  </div>
                </div>
              }
            </div>
          </section>
        }

        <!-- ── PRIZE STRUCTURE ───────────────────────────────────────── -->
        <section class="section">
          <div class="section-head">
            <h2 class="section-title">🏆 Prize Structure</h2>
            <span class="section-sub">Same rules apply across all contests</span>
          </div>
          <div class="prize-strip">
            @for (entry of prizeEntries; track entry[0]) {
              <div class="prize-tile" [class.highlight]="entry[0] === 'FULL_HOUSE'">
                <div class="prize-tile-icon">{{ prizeIcon(entry[0]) }}</div>
                <div class="prize-tile-name">{{ entry[1].label }}</div>
                <div class="prize-tile-amt">₹{{ entry[1].amount }}</div>
                <div class="prize-tile-desc">{{ entry[1].desc }}</div>
              </div>
            }
          </div>
        </section>

        <!-- ── HOW TO PLAY ────────────────────────────────────────────── -->
        <section class="section">
          <div class="how-grid">
            <div class="how-step">
              <div class="how-num">1</div>
              <div class="how-text">
                <strong>Join a Contest</strong>
                <span>Pay entry fee, get a unique 3×9 Housie card</span>
              </div>
            </div>
            <div class="how-arrow">→</div>
            <div class="how-step">
              <div class="how-num">2</div>
              <div class="how-text">
                <strong>Numbers Called</strong>
                <span>One number every 20 seconds, announced by voice</span>
              </div>
            </div>
            <div class="how-arrow">→</div>
            <div class="how-step">
              <div class="how-num">3</div>
              <div class="how-text">
                <strong>Claim Prizes</strong>
                <span>Complete rows, top half or full house to win</span>
              </div>
            </div>
            <div class="how-arrow">→</div>
            <div class="how-step">
              <div class="how-num">4</div>
              <div class="how-text">
                <strong>Instant Credit</strong>
                <span>Winnings hit your wallet the moment you win</span>
              </div>
            </div>
          </div>
        </section>

        <!-- ── CONTESTS ──────────────────────────────────────────────── -->
        <section class="section">
          <div class="section-head">
            <h2 class="section-title">🎮 Live Contests</h2>
            <div class="filter-row">
              @for (f of filters; track f.val) {
                <button class="filter-btn" [class.active]="activeFilter() === f.val"
                  (click)="activeFilter.set(f.val)">{{ f.label }}</button>
              }
            </div>
          </div>

          <div class="contests-grid">
            @for (c of filteredContests(); track c.id) {
              <div class="contest-card" [style.--accent]="c.colorHex">
                <!-- Card header stripe -->
                <div class="cc-stripe" [style.background]="c.colorHex"></div>

                <div class="cc-body">
                  <div class="cc-top">
                    <div class="cc-name">{{ c.name }}</div>
                    <div class="cc-badges">
                      @if (c.badge) {
                        <span class="badge" [style.background]="c.colorHex + '18'"
                          [style.color]="c.colorHex" [style.border-color]="c.colorHex + '44'">
                          {{ c.badge }}
                        </span>
                      }
                      <span class="status-pill" [class]="'s-' + c.status.toLowerCase()">
                        {{ statusLabel(c.status) }}
                      </span>
                    </div>
                  </div>

                  <div class="cc-stats">
                    <div class="cc-stat">
                      <div class="cc-stat-lbl">Prize Pool</div>
                      <div class="cc-stat-val pool">₹{{ c.prizePool | number }}</div>
                    </div>
                    <div class="cc-stat-div"></div>
                    <div class="cc-stat">
                      <div class="cc-stat-lbl">Entry Fee</div>
                      <div class="cc-stat-val">₹{{ c.entryFee }}</div>
                    </div>
                    <div class="cc-stat-div"></div>
                    <div class="cc-stat">
                      <div class="cc-stat-lbl">Players</div>
                      <div class="cc-stat-val" [class.urgent]="c.spotsLeft <= 2">
                        {{ c.currentPlayers }}/{{ c.maxPlayers }}
                      </div>
                    </div>
                  </div>

                  <!-- Fill bar -->
                  <div class="cc-fill-wrap">
                    <div class="cc-fill-track">
                      <div class="cc-fill-bar" [style.width.%]="c.fillPercentage"
                        [style.background]="c.colorHex"></div>
                    </div>
                    <span class="cc-spots">{{ c.spotsLeft }} spots left</span>
                  </div>

                  <!-- Prize preview chips -->
                  <div class="cc-prizes">
                    @for (entry of prizeEntries.slice(0,4); track entry[0]) {
                      <span class="cc-prize-chip">{{ entry[1].label }}: ₹{{ entry[1].amount }}</span>
                    }
                  </div>

                  <!-- Action -->
                  <div class="cc-action">
                    @if (c.status === 'IN_PROGRESS') {
                      <button class="btn-watch" (click)="go(c)">👁 Watch Live</button>
                    } @else if (c.status === 'COMPLETED') {
                      <button class="btn-done" disabled>Completed</button>
                    } @else if (!canAfford(c)) {
                      <div class="cant-afford">
                        <span>Need ₹{{ (c.entryFee - (user()?.walletBalance ?? 0)) | number:'1.0-0' }} more</span>
                        <button class="btn-topup" routerLink="/wallet">Top Up</button>
                      </div>
                    } @else {
                      <button class="btn-join" (click)="join(c)">
                        Join for ₹{{ c.entryFee }} →
                      </button>
                    }
                  </div>
                </div>
              </div>
            }
          </div>
        </section>

      </div>
    </div>
  `,
  styleUrls: ['./lobby.component.scss']
})
export class LobbyComponent implements OnInit, OnDestroy {
  contests     = signal<Contest[]>([]);
  myContests   = signal<any[]>([]);
  activeFilter = signal('all');
  user         = computed(() => this.auth.user());
  initial      = computed(() => this.user()?.fullName?.[0]?.toUpperCase() ?? 'U');
  firstName    = computed(() => this.user()?.fullName?.split(' ')[0] ?? '');
  prizeEntries = Object.entries(PRIZE_DEFINITIONS);
  filters      = [
    { val: 'all', label: 'All' },
    { val: 'low', label: 'Under ₹100' },
    { val: 'high', label: '₹500+' },
  ];
  filteredContests = computed(() => {
    const f = this.activeFilter();
    return this.contests().filter(c =>
      f === 'low' ? c.entryFee <= 100 : f === 'high' ? c.entryFee > 500 : true
    );
  });
  private poll?: Subscription;

  constructor(
    private auth: AuthService,
    private cs: ContestService,
    private router: Router,
    private http: HttpClient,
  ) {}

  ngOnInit() {
    this.load();
    this.loadMyContests();
    this.poll = interval(10_000).pipe(switchMap(() => this.cs.getActiveContests()))
      .subscribe(d => this.contests.set(d));
  }
  ngOnDestroy() { this.poll?.unsubscribe(); }

  load() { this.cs.getActiveContests().subscribe(d => this.contests.set(d)); }

  loadMyContests() {
    this.http.get<any[]>(`${environment.apiUrl}/private-contests/my`)
      .subscribe({ next: d => this.myContests.set(d), error: () => {} });
  }

  canAfford(c: Contest) { return (this.user()?.walletBalance ?? 0) >= c.entryFee; }

  join(c: Contest) {
    this.cs.joinContest(c.id).subscribe({
      next: res => {
        this.auth.updateWallet((this.user()?.walletBalance ?? 0) - c.entryFee);
        this.router.navigate(['/game', c.id], { state: { cardData: res.cardData } });
      },
      error: e => alert(e?.error?.message ?? 'Could not join'),
    });
  }
  go(c: Contest) { this.router.navigate(['/game', c.id]); }
  logout()       { this.auth.logout(); }

  statusLabel(s: string) {
    return { WAITING: 'Open', IN_PROGRESS: 'Live', STARTING: 'Starting', COMPLETED: 'Ended' }[s] ?? s;
  }
  prizeIcon(key: string) {
    return { EARLY_FIVE:'⚡', FIRST_LINE:'1️⃣', SECOND_LINE:'2️⃣',
             THIRD_LINE:'3️⃣', TOP_HALF:'🔝', FULL_HOUSE:'🏆' }[key] ?? '🎯';
  }
}
