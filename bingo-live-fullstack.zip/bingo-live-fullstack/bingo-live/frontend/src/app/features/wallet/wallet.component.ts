import { Component, OnInit, signal } from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { RouterLink }    from '@angular/router';
import { AuthService }   from '../../core/services/auth.service';
import { WalletService } from '../../core/services/wallet.service';
import { WalletTransaction } from '../../shared/models';

@Component({
  selector: 'app-wallet',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page">
      <header class="header">
        <div class="logo">🎱 BingoLive</div>
        <button class="btn-back" routerLink="/lobby">← Back to Lobby</button>
      </header>

      <main class="main">
        <h2>💰 My Wallet</h2>

        <!-- Balance Card -->
        <div class="balance-card">
          <div class="bal-label">Available Balance</div>
          <div class="bal-amount">₹{{ user()?.walletBalance | number:'1.2-2' }}</div>
          <div class="bal-sub">Instant credit on win • No withdrawal fee</div>
        </div>

        <!-- Add Funds -->
        <div class="section-card">
          <h3>Add Funds</h3>
          <div class="presets">
            @for (p of presets; track p) {
              <button class="preset-btn" [class.selected]="amount() === p" (click)="amount.set(p)">
                ₹{{ p }}
              </button>
            }
          </div>
          <div class="custom-row">
            <input type="number" [value]="amount()" (input)="amount.set(+$any($event.target).value)"
              placeholder="Custom amount" min="10" />
            <button class="btn-add" (click)="addFunds()" [disabled]="loading()">
              {{ loading() ? 'Processing…' : 'Add ₹' + amount() }}
            </button>
          </div>
          @if (successMsg()) { <div class="success-msg">✅ {{ successMsg() }}</div> }
          @if (errorMsg())   { <div class="error-msg">⚠ {{ errorMsg() }}</div> }
        </div>

        <!-- Transaction History -->
        <div class="section-card">
          <h3>Transaction History</h3>
          @if (txns().length === 0) {
            <div class="empty">No transactions yet.</div>
          } @else {
            <div class="txn-list">
              @for (t of txns(); track t.id) {
                <div class="txn-row">
                  <div class="txn-icon">{{ txnIcon(t.type) }}</div>
                  <div class="txn-info">
                    <div class="txn-desc">{{ t.description }}</div>
                    <div class="txn-date">{{ t.createdAt | date:'d MMM y, h:mm a' }}</div>
                  </div>
                  <div class="txn-amt" [class.credit]="t.amount > 0" [class.debit]="t.amount < 0">
                    {{ t.amount > 0 ? '+' : '' }}₹{{ t.amount | number:'1.0-0' }}
                  </div>
                </div>
              }
            </div>
          }
        </div>
      </main>
    </div>
  `,
  styles: [`
    .page { min-height:100vh; background:linear-gradient(135deg,#0A0B1E,#111236,#0D0E24);
      font-family:'Inter','Segoe UI',sans-serif; color:#E8E8F0; }
    .header { position:sticky; top:0; z-index:100; background:rgba(255,255,255,.04);
      backdrop-filter:blur(20px); border-bottom:1px solid rgba(108,99,255,.3);
      padding:0 24px; height:60px; display:flex; align-items:center; justify-content:space-between; }
    .logo { font-size:20px; font-weight:800;
      background:linear-gradient(90deg,#6C63FF,#FF6584); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
    .btn-back { padding:6px 14px; border-radius:8px; border:1px solid rgba(255,255,255,.12);
      background:transparent; color:#888; cursor:pointer; font-size:13px; }
    .main { max-width:600px; margin:0 auto; padding:28px 16px; }
    h2 { font-size:24px; font-weight:800; margin:0 0 20px; }
    h3 { font-size:16px; font-weight:700; margin:0 0 16px; color:#E8E8F0; }
    .balance-card { background:linear-gradient(135deg,rgba(108,99,255,.2),rgba(255,101,132,.15));
      border:1px solid rgba(108,99,255,.3); border-radius:20px; padding:32px; text-align:center; margin-bottom:20px; }
    .bal-label  { font-size:14px; color:#888; margin-bottom:8px; }
    .bal-amount { font-size:52px; font-weight:900; color:#43D39E; }
    .bal-sub    { font-size:12px; color:#555; margin-top:8px; }
    .section-card { background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08);
      border-radius:16px; padding:24px; margin-bottom:20px; }
    .presets { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin-bottom:14px; }
    .preset-btn { padding:14px; border-radius:10px; border:1px solid rgba(255,255,255,.1);
      background:rgba(255,255,255,.04); color:#888; cursor:pointer; font-weight:700; font-size:16px; }
    .preset-btn.selected { background:rgba(108,99,255,.15); border-color:#6C63FF; color:#A5A0FF; }
    .custom-row { display:flex; gap:10px; }
    input { flex:1; padding:12px 16px; background:rgba(255,255,255,.06);
      border:1px solid rgba(255,255,255,.12); border-radius:10px;
      color:#E8E8F0; font-size:15px; outline:none; }
    input:focus { border-color:#6C63FF; }
    .btn-add { padding:12px 20px; border:none; border-radius:10px; cursor:pointer; font-weight:700;
      font-size:15px; background:linear-gradient(135deg,#43D39E,#1fa882); color:#fff; white-space:nowrap; }
    .btn-add:disabled { opacity:.6; cursor:not-allowed; }
    .success-msg { color:#43D39E; font-size:13px; margin-top:10px; }
    .error-msg   { color:#FF6584; font-size:13px; margin-top:10px; }
    .txn-list { display:flex; flex-direction:column; gap:2px; }
    .txn-row { display:flex; align-items:center; gap:12px; padding:12px 0;
      border-bottom:1px solid rgba(255,255,255,.04); }
    .txn-icon { font-size:22px; width:36px; text-align:center; }
    .txn-info { flex:1; }
    .txn-desc { font-size:14px; font-weight:500; }
    .txn-date { font-size:12px; color:#555; margin-top:2px; }
    .txn-amt  { font-size:16px; font-weight:800; }
    .credit { color:#43D39E; }
    .debit  { color:#FF6584; }
    .empty  { text-align:center; color:#555; padding:24px 0; }
  `]
})
export class WalletComponent implements OnInit {
  user       = this.authService.user;
  txns       = signal<WalletTransaction[]>([]);
  amount     = signal(100);
  loading    = signal(false);
  successMsg = signal('');
  errorMsg   = signal('');
  presets    = [100, 250, 500, 1000];

  constructor(private authService: AuthService, private walletService: WalletService) {}

  ngOnInit(): void {
    this.walletService.getHistory().subscribe(data => this.txns.set(data));
  }

  addFunds(): void {
    if (this.amount() < 10) return this.errorMsg.set('Minimum ₹10');
    this.loading.set(true); this.errorMsg.set(''); this.successMsg.set('');
    this.walletService.addFunds(this.amount()).subscribe({
      next: (res) => {
        this.authService.updateWallet(res.balance);
        this.successMsg.set(`₹${this.amount()} added successfully!`);
        this.loading.set(false);
        this.walletService.getHistory().subscribe(data => this.txns.set(data));
      },
      error: (e) => { this.errorMsg.set(e?.error?.message ?? 'Failed to add funds'); this.loading.set(false); }
    });
  }

  txnIcon(type: string): string {
    const map: Record<string,string> = {
      DEPOSIT:'💳', CONTEST_JOIN:'🎮', PRIZE_CREDIT:'🏆', WITHDRAWAL:'🏧', REFUND:'↩️'
    };
    return map[type] ?? '💰';
  }
}
