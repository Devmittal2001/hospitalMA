// ─── Auth ─────────────────────────────────────────────────────────────────────

export interface User {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  walletBalance: number;
  kycVerified: boolean;
  createdAt: string;
}

export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  tokenType: string;
  user: User;
}

// ─── Contest ─────────────────────────────────────────────────────────────────

export type GameStatus = 'WAITING' | 'STARTING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';

export interface Contest {
  id: number;
  name: string;
  prizePool: number;
  entryFee: number;
  maxPlayers: number;
  currentPlayers: number;
  status: GameStatus;
  badge: string;
  colorHex: string;
  createdAt: string;
  startedAt: string | null;
  spotsLeft: number;
  fillPercentage: number;
}

// ─── Game ─────────────────────────────────────────────────────────────────────

export type PrizeType =
  | 'EARLY_FIVE'
  | 'FIRST_LINE'
  | 'SECOND_LINE'
  | 'THIRD_LINE'
  | 'TOP_HALF'
  | 'FULL_HOUSE';

export type GameMessageType =
  | 'NUMBER_CALLED'
  | 'PRIZE_WON'
  | 'GAME_STATUS'
  | 'COUNTDOWN';

export interface GameMessage {
  type: GameMessageType;
  gameStatus?: GameStatus;

  // NUMBER_CALLED
  calledNumber?: number;
  callSequence?: number;
  allCalledNumbers?: number[];
  nextCallInSeconds?: number;

  // PRIZE_WON
  winnerId?: number;
  winnerName?: string;
  prizeType?: PrizeType;
  prizeDisplayName?: string;
  prizeAmount?: number;
  calledNumbersAtWin?: number;

  // GAME_STATUS
  currentPlayers?: number;
  maxPlayers?: number;
  message?: string;

  // COUNTDOWN
  countdownSeconds?: number;

  // Shared
  claimedPrizes?: Record<string, string>;
}

// ─── Prize Definitions ────────────────────────────────────────────────────────
// Single source of truth — used in game board, lobby prize strip, and How to Win panel.
// Must match PrizeType enum values in backend PrizeType.java exactly.

export interface PrizeDef {
  label: string;
  desc: string;
  amount: number;
}

export const PRIZE_DEFINITIONS: Record<PrizeType, PrizeDef> = {
  EARLY_FIVE:  { label: 'Early Five',  desc: 'Any 5 numbers marked',     amount: 15  },
  FIRST_LINE:  { label: '1st Line',    desc: 'Top row complete',          amount: 10  },
  SECOND_LINE: { label: '2nd Line',    desc: 'Middle row complete',       amount: 10  },
  THIRD_LINE:  { label: '3rd Line',    desc: 'Bottom row complete',       amount: 10  },
  TOP_HALF:    { label: 'Top Half',    desc: 'Top two rows complete',     amount: 25  },
  FULL_HOUSE:  { label: 'Full House',  desc: 'All 15 numbers marked',     amount: 100 },
};

// Typed entry pairs for @for loops in templates
// Usage: @for (entry of prizeEntries(); track entry[0]) { {{ entry[1].label }} }
export type PrizeEntry = [PrizeType, PrizeDef];

// ─── Wallet ───────────────────────────────────────────────────────────────────

export type TransactionType = 'DEPOSIT' | 'CONTEST_JOIN' | 'PRIZE_CREDIT' | 'WITHDRAWAL' | 'REFUND';

export interface WalletTransaction {
  id: number;
  type: TransactionType;
  amount: number;
  balanceAfter: number;
  description: string;
  createdAt: string;
}
