export const environment = {
  production: false,
  apiUrl: '/api',         // proxied to http://localhost:8080/api in dev
  wsUrl: 'http://localhost:8080/api',
};
